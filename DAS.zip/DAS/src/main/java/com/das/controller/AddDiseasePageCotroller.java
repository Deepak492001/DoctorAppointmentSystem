package com.das.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.das.dao.RegisDAO;
import com.das.model.AddDiseaseDetails;
import com.das.model.AddDiseaseName;
import com.das.model.DocAdditionalDetails;

@Controller
public class AddDiseasePageCotroller 
{
	@Autowired
	private RegisDAO regisDAO;
	
	@RequestMapping("/addDisease")
	public String addDisease(@RequestParam("ye") String email, Model m)
	{
		m.addAttribute("email",email);
		DocAdditionalDetails dad = this.regisDAO.getDoctorDetailsForDashboard(email);
		List<AddDiseaseName> adn = this.regisDAO.getAllDisease();
		m.addAttribute("doctorName", dad.getName());
		m.addAttribute("timings", dad.getTimings());
		m.addAttribute("email", dad.getEmail());
		m.addAttribute("adn", adn);
		return "AddDisease";
	}
	
	@RequestMapping("/addDisease/addDiseaseName")
	public String addDiseaseName(@RequestParam("ye") String email, @ModelAttribute AddDiseaseName adn, RedirectAttributes ra)
	{
		ra.addFlashAttribute("email",email);
		this.regisDAO.addDiseaseName(adn);
		return "redirect:/addDisease?ye="+email;
	}
	
	@RequestMapping("/addDisease/addDiseaseDetails")
	public String addDiseaseDetails(@RequestParam("ye") String email, @ModelAttribute AddDiseaseDetails add, RedirectAttributes ra)
	{
		ra.addFlashAttribute("email",email);
		this.regisDAO.addDiseaseDetails(add);

		return "redirect:/addDisease?ye="+email;
	}
	
	
}
