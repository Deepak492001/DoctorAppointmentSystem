package com.das.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.das.dao.RegisDAO;
import com.das.model.DocAdditionalDetails;
import com.das.model.Feedback;
import com.das.model.Scheme;
import com.das.model.UserDetails;

@Controller
public class AdminDashboardController 
{
	@Autowired
	private RegisDAO regisDAO;
	
	@RequestMapping("/adminDashboard")
	public String adminDash()
	{
		return "AdminDashboard";
	}
	
	@RequestMapping("/adminDashboard/addScheme")
	public String addScheme(@ModelAttribute Scheme sc, RedirectAttributes ra)
	{		
		Scheme s = new Scheme(sc.getScheme_name(), sc.getAnnounced_by(), sc.getDescription(), sc.getBenefits(), sc.getTargeted_people(), sc.getWhere_to_avail(), sc.getDocuments(), sc.getLink(), new SimpleDateFormat("dd-MM-yyyy").format(new Date()));
		String msg = this.regisDAO.addScheme(s);		
		ra.addFlashAttribute("msg", msg);
		return "redirect:/adminDashboard/allScheme";
	}
	
	@RequestMapping("/adminDashboard/allScheme")
	public String allScheme(Model m)
	{
		List<Scheme> allScheme = this.regisDAO.getAllScheme();
		m.addAttribute("allScheme", allScheme);
		m.addAttribute("scheme_count", (Long) this.regisDAO.getSchemeCount());
		return "AllScheme";
	}
	
	@RequestMapping("/adminDashboard/deleteScheme")
	public String deleteScheme(@RequestParam("sn") String sn, RedirectAttributes ra)
	{
		String msg = this.regisDAO.deleteScheme(sn);
		ra.addFlashAttribute("msg", msg);		
		return "redirect:/adminDashboard/allScheme";
	}
	
	@RequestMapping("/adminDashboard/printScheme")
	public String printScheme(@RequestParam("sn") String sn, Model m)
	{
		Scheme s = this.regisDAO.printScheme(sn);
		m.addAttribute("p", s);
		return "PrintScheme";
	}
	
	@RequestMapping("/adminDashboard/allUser")
	public String allUsers(Model m)
	{
		Long doc_count = this.regisDAO.getCount("doc");
		Long pat_count = this.regisDAO.getCount("pat");
		List<DocAdditionalDetails> dad =  this.regisDAO.getAllDoctor();
		List<UserDetails> ud =  this.regisDAO.getAllPatient();
		m.addAttribute("dad", dad);
		m.addAttribute("ud", ud);
		m.addAttribute("doc_count", doc_count);
		m.addAttribute("pat_count", pat_count);
		return "AllUser";
	}
	
	@RequestMapping("/adminDashboard/deleteUser")
	public String deleteUser(@RequestParam("type") String type, @RequestParam("email") String email, RedirectAttributes ra)
	{
		this.regisDAO.accountDelete(type, email);
		ra.addFlashAttribute("msg", "Successfully deleted user with email = "+email);		
		return "redirect:/adminDashboard/allUser";
	}
	
	@RequestMapping("/adminDashboard/allFeedbacks")
	public String allFeedbacks( Model m)
	{
		long l = this.regisDAO.getCountFeedback();
		List<Feedback> feed = this.regisDAO.getAllFeedbacks();
		m.addAttribute("feed", feed);	
		m.addAttribute("total", l);	
		return "AllFeedbacks";
	}
	
}
