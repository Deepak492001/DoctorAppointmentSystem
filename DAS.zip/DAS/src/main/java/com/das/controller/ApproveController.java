package com.das.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.das.dao.RegisDAO;

@Controller
public class ApproveController 
{
	
	@Autowired
	private RegisDAO regisDAO;
		
	@RequestMapping("/approve")
	public String approve(@RequestParam("ye") String email, @RequestParam("date") String date, Model m)
	{
		String msg = this.regisDAO.updateStatus("Approved", date);
		m.addAttribute("msg",msg);
		return "redirect:/doctorDashboard?ye="+email;
	}
}
