package com.das.controller;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.das.dao.RegisDAO;
import com.das.model.BookAppointment;

@Controller
public class BookAppointmentPageController 
{
	@Autowired
	private RegisDAO regisDAO;
	
	@RequestMapping("/bookAppointment")
	public String book(@RequestParam("type") String type, @RequestParam("mode") String mode, @RequestParam("de") String de, @RequestParam("ye") String ye, Model m, RedirectAttributes ra)
	{
		System.out.println("BookAppointment.jsp will open now...");
		if(ye.equals(""))
		{
			return "redirect:/LoginPage/loginForAppointment?type="+type+"&mode="+mode+"&de="+de;
		}
		else
		{
			m.addAttribute("mode",mode);
			m.addAttribute("yourEmail",ye);
			m.addAttribute("docEmail",de);
			m.addAttribute("currentDateAndTime",new SimpleDateFormat("dd-MM-yyyy").format(new Date())+" "+new SimpleDateFormat("hh:mm:ss").format(new Date()));		
			return "BookAppointment";
		}
	}
	
	@RequestMapping("/bookAction")
	public String bookAction(@ModelAttribute BookAppointment book,Model m)
	{
		String msg = regisDAO.bookAppointment(book);	
		if(msg.startsWith("Successfully"))
		{
			m.addAttribute("msg",msg);
			m.addAttribute("ye",book.getPatientEmail());
			this.regisDAO.sendEmail(book.getPatientEmail(), null, "appointment booked" , book, null);
			return "redirect:/successfullyBooked";
		}
		else
		{
			m.addAttribute("msg","Booking Failed!!!");
			return "redirect:/failedBooking";
		}
	}
	
	
	
}
