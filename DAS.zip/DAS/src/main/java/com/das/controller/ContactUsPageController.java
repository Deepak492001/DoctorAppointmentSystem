package com.das.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.das.dao.RegisDAO;
import com.das.model.ContactUs;

@Controller
public class ContactUsPageController 
{
	@Autowired
	private RegisDAO regisDAO;
	
	@RequestMapping("/ContactUs")
	public String contactUsForm() 
	{
		return "ContactUs";
	}

	@RequestMapping(path = "/addContactUsInfo", method = RequestMethod.POST)
	public String addContactUsDetails(@ModelAttribute("contactUs") ContactUs contactUs , RedirectAttributes redirectAttributes) {
		
		String msg = this.regisDAO.addContactUsInfo(contactUs);
        redirectAttributes.addFlashAttribute("contact_us_msg",msg);
		return "redirect:/ContactUs";
	}
}
