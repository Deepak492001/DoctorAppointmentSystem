package com.das.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.das.dao.RegisDAO;
import com.das.model.DocAdditionalDetails;
import com.das.model.SignUpDoctor;

@Controller
public class DocProfilePageController 
{
	@Autowired
	private RegisDAO regisDAO;
	
	@RequestMapping("/docProfile")
	public String docProfile(@RequestParam("ye") String email, Model m)
	{
		DocAdditionalDetails dad = this.regisDAO.getDocAdditionalDetails(email);
		SignUpDoctor sup = this.regisDAO.getDoctorDetails(email);
		m.addAttribute("p", dad);
		m.addAttribute("s", sup);
		return "DocProfile";
	}
	
}
