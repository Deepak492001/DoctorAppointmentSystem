package com.das.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.das.dao.RegisDAO;
import com.das.model.DocAdditionalDetails;

@Controller
public class DoctorAdditionalDetailsPageController 
{
	@Autowired
	private RegisDAO regisDAO;
	
	@RequestMapping("/docAdditionalDetails")
	public String docAdditionalDetails(Model m)
	{
		System.out.println("DocAdditionalDetails.jsp will open now....");
		ArrayList<String> cities = (ArrayList<String>) this.regisDAO.getCities();
		m.addAttribute("cities", cities);
		return "DocAdditionalDetails";
	}
	
	@RequestMapping("/docMoreDetails")
	public String docMoreDetails(@ModelAttribute DocAdditionalDetails dad,Model m)
	{
		System.out.println("After inserting additional details of doctor OTPVerification.jsp will open now....");
		String email = regisDAO.addDocAdditionalDetails(dad);				
		return "redirect:/OTPVerification?i=1&ye="+email;
	}
	
}
