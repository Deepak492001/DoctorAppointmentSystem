package com.das.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.das.dao.RegisDAO;
import com.das.model.BookAppointment;
import com.das.model.DocAdditionalDetails;
import com.das.model.GeneratePrescription;
import com.das.model.ViewPrescription;

@Controller
public class DoctorDashboardPageController 
{
	@Autowired
	private RegisDAO regisDAO;
	
	@RequestMapping("/doctorDashboard")
	public String doctorDash(@RequestParam("ye") String email,Model m)
	{
		System.out.println("DoctorDashboard.jsp will open now...");
		
		DocAdditionalDetails dad = this.regisDAO.getDoctorDetailsForDashboard(email);
		
		
		int pending = regisDAO.countAppointment(email, "Pending");
		int today = regisDAO.countTodayAppointments(email);
		int total = regisDAO.getTotalAppointmentBooked(email);
		
		List<BookAppointment> approvedList =regisDAO.getAppointments(email,"Approved");
		List<BookAppointment> pendingList =regisDAO.getAppointments(email,"Pending");
		
				
		m.addAttribute("email",email);
		
		m.addAttribute("doctorName",dad.getName());
		m.addAttribute("clinicName",dad.getHospital_name());
		m.addAttribute("clinicAddress",dad.getLocation());
		m.addAttribute("timings",dad.getTimings());
		m.addAttribute("today",today);	
		m.addAttribute("total",total);	
		m.addAttribute("pending",pending);
		m.addAttribute("approvedList",approvedList);
		m.addAttribute("pendingList",pendingList);
		
		return "DoctorDashboard";
	}
	
	@RequestMapping("/doctorDashboard/uploadLink")
	public String uploadLink(@RequestParam("ye") String ye, @RequestParam("bookedDate") String bookedDate, @RequestParam("patientEmail") String patientEmail, @RequestParam("platformName") String platformName, @RequestParam("meetingLink") String meetingLink, RedirectAttributes ra)
	{
		String msg = this.regisDAO.uploadLink(patientEmail, bookedDate, platformName, meetingLink);		
		if(msg.startsWith("Successfull"))
		{
			ra.addFlashAttribute("msg",msg);
			ra.addFlashAttribute("type","success");
			return "redirect:/doctorDashboard?ye="+ye;
		}
		else
		{
			ra.addFlashAttribute("msg",msg);
			ra.addFlashAttribute("type","danger");
			return "redirect:/doctorDashboard?ye="+ye;
		}
	}
		
	@RequestMapping(value="/doctorDashboard/generatePrescription", method=RequestMethod.POST)
	public String generatePrescriptionAction(@RequestParam("ye") String docEmail, @RequestParam("medicineDetails") String medicineDetails, @RequestParam("bookedDate") String bookedDate, RedirectAttributes ra)
	{		
		GeneratePrescription genPre = new GeneratePrescription(bookedDate, docEmail, medicineDetails, new SimpleDateFormat("dd/MM/yyyy hh:mm:ss").format(new Date()));
		System.out.println("Medicine Details = "+medicineDetails);
		int pid = regisDAO.insertPrescription(genPre, bookedDate);
		if(pid!=0 )
		{
			ra.addFlashAttribute("msg","Prescription succesfully generated with Pno ="+pid);
			ra.addFlashAttribute("type","success");
			return "redirect:/doctorDashboard?ye="+docEmail;
		}
		else
		{
			ra.addFlashAttribute("type","danger");			
			return "redirect:/doctorDashboard?ye="+docEmail;
		}
	}
	
	@RequestMapping(value="/doctorDashboard/updateAndApprove", method=RequestMethod.POST)
	public String approve(@RequestParam("ye") String email, @RequestParam("bookedDate") String bookedDate, @RequestParam("appointmentDate") String appointmentDate,@RequestParam("appointmentTime") String appointmentTime, RedirectAttributes ra)
	{		
		this.regisDAO.updateAppointmentDateAndTime(email,bookedDate,appointmentDate, appointmentTime);
		
		String msg = this.regisDAO.updateStatus("Approved", bookedDate);
		ra.addFlashAttribute("msg",msg);
		ra.addFlashAttribute("type","success");
		return "redirect:/doctorDashboard?ye="+email;
	}
	
	@RequestMapping("/doctorDashboard/viewPreAction")
	public String viewPreAction(@RequestParam("Pid") String pid)
	{		
		return "redirect:/viewPrescription?Pid="+pid;
	}
	
	@RequestMapping("/doctorDashboard/timingsUpdate")
	public String timingsUpdate(@RequestParam("ye") String email, @RequestParam("timings") String timings, RedirectAttributes ra)
	{
		
		String msg = this.regisDAO.updateOPDTimings(email, timings);
		if(msg.startsWith("Successfully"))
		{
			ra.addFlashAttribute("msg",msg);
			ra.addFlashAttribute("type","success");
			return "redirect:/doctorDashboard?ye="+email;
		}
		else
		{
			ra.addFlashAttribute("msg",msg);
			ra.addFlashAttribute("type","danger");
			return "redirect:/doctorDashboard?ye="+email;
		}
	}
	
	@RequestMapping("/dashboard/changePassword")
	public String changePassword(@RequestParam("type") String type, @RequestParam("ye") String email, @RequestParam("currPassword") String currPassword, @RequestParam("newPassword") String newPassword, RedirectAttributes ra)
	{		
		String msg = this.regisDAO.changePassword(type, email, currPassword, newPassword);
		if(msg.startsWith("Your"))
		{
			ra.addAttribute("msg",msg);
			ra.addFlashAttribute("type","success");
			return "redirect:/LoginPage";
		}
		else
		{			
			ra.addFlashAttribute("msg",msg);
			ra.addFlashAttribute("type","danger");
			
			if(type.equals("doc"))
				return "redirect:/doctorDashboard?ye="+email;
			else 
				return "redirect:/patientDashboard?ye="+email;
		}
	}
	
	@RequestMapping("dashboard/accountDelete")
	public String accountDelete(@RequestParam("type") String type, @RequestParam("ye") String email, Model m)	
	{
		this.regisDAO.sendEmail(email, null, "account delete", null, type);
		this.regisDAO.accountDelete(type, email);		
		return "redirect:/";
	}
	
	@RequestMapping("/patientHistory")
	public String patientHistory(@RequestParam("ye") String email, Model m)
	{
		int totalPatientTreated = regisDAO.countAppointment(email, "Complete");
		DocAdditionalDetails dad = this.regisDAO.getDoctorDetailsForDashboard(email);		
		List<BookAppointment> completeList = this.regisDAO.getAppointments(email, "Complete");
		m.addAttribute("completeList", completeList);
		m.addAttribute("doctorName", dad.getName());
		m.addAttribute("email", dad.getEmail());
		m.addAttribute("timings",dad.getTimings());
		m.addAttribute("clinicName",dad.getHospital_name());
		m.addAttribute("clinicAddress",dad.getLocation());		
		m.addAttribute("totalPatientTreated", totalPatientTreated);
		return "PatientHistory";
	}
	
	@RequestMapping("dashboard/feedback")
	public String feedback(@RequestParam("type") String type, @RequestParam("name") String name, @RequestParam("email") String email, @RequestParam("feedback") String feedback, RedirectAttributes ra)
	{
		String msg = this.regisDAO.insertFeedback(name, email, feedback);
		if(type.equals("doc"))
		{
			ra.addFlashAttribute("msg", msg);
			ra.addFlashAttribute("type", "success");
			return "redirect:/doctorDashboard?ye="+email;
		}
		else if(type.equals("pat"))
		{			
			return "redirect:/patientDashboard?ye="+email;
		}		
		return null;	
	}
}
