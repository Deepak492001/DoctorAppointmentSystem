package com.das.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.das.dao.RegisDAO;
import com.das.model.SignIn;
import com.das.model.SignUpDoctor;


@Controller
public class DoctorSignUpPageController 
{
	@Autowired
	private RegisDAO regisDAO;
	
	@RequestMapping("/docSignUp")
	public String docsignup()
	{
		System.out.println("DocSignUp.jsp will open.....");
		return "DocSignUp";
	}
	
	@RequestMapping("/docRegisAction")
	public String docRegisAction(@ModelAttribute SignUpDoctor doc,Model m)
	{		
		
		String msg = regisDAO.docSignUp(doc);
		
		if(msg.startsWith("Successfully"))
		{
			SignIn si=new SignIn(doc.getEmail(),doc.getPassword(),doc.getName(),"doc","unverified");
			regisDAO.insertIntoSignIn(si);
			m.addAttribute("msg",msg);
			m.addAttribute("name",doc.getName());
			m.addAttribute("email",doc.getEmail());
			return "DocAdditionalDetails";
		}
		else
		{
			m.addAttribute("msg",msg);
			return "DocSignUp";		
		}
	}
}
