package com.das.controller;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class FailedBookingPageController 
{
	@RequestMapping("/failedBooking")
	public String failed(@RequestParam("msg") String msg,Model m)
	{
		m.addAttribute("msg",msg);
		return "FailedBooking";
	}
}
