package com.das.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.das.dao.RegisDAO;
import com.das.model.SignIn;

@Controller
public class LoginPageController 
{
	@Autowired
	private RegisDAO regisDAO;
	
	@RequestMapping("/loginDetails")
	public String signUp(@RequestParam("email") String email,@RequestParam("pass") String password,RedirectAttributes ra)
	{					
		SignIn si = regisDAO.getSignInDetails(email);
		
		if( ((si.getEmail()).equals(email)) && ((si.getPassword()).equals(password)) && ((si.getType()).equals("doc")) && ((si.getStatus()).equals("verified")))
		{
			ra.addFlashAttribute("msg","Successfully signed in!!!");
			ra.addFlashAttribute("type","success");
			return "redirect:/doctorDashboard?ye="+email;
		}
		else if( ((si.getEmail()).equals(email)) && ((si.getPassword()).equals(password)) && ((si.getType()).equals("doc")) && ((si.getStatus()).equals("unverified")))
		{
			return "redirect:/OTPVerification?i=1&ye="+email;
		}				
		else if( ((si.getEmail()).equals(email)) && ((si.getPassword()).equals(password)) && ((si.getType()).equals("pat")) && ((si.getStatus()).equals("verified")))
		{			
			return "redirect:/patientDashboard?ye="+email;
		}
		else if( ((si.getEmail()).equals(email)) && ((si.getPassword()).equals(password)) && ((si.getType()).equals("pat")) && ((si.getStatus()).equals("unverified")))
		{
			return "redirect:/OTPVerification?i=1&ye="+email;
		}
		else if( ((si.getEmail()).equals(email)) && ((si.getPassword()).equals(password)) && ((si.getType()).equals("admin")) && ((si.getStatus()).equals("verified")))
		{
			return "redirect:/adminDashboard";
		}
		else
		{
			ra.addFlashAttribute("msg","Either Your Email or Password is incorrect!!!");
			return "redirect:/LoginPage";
		}
	}
	
	@RequestMapping("/LoginPage/loginAppointDetails")
	public String loginForAppointment(@RequestParam("type") String type, @RequestParam("mode") String mode, @RequestParam("de") String de, @RequestParam("email") String email, @RequestParam("pass") String password,RedirectAttributes ra)
	{					
		SignIn si = regisDAO.getSignInDetails(email);
		
		if( ((si.getEmail()).equals(email)) && ((si.getPassword()).equals(password)) && ((si.getType()).equals("pat")) && ((si.getStatus()).equals("verified")))
		{
			ra.addFlashAttribute("msg","Successfully signed in!!!");
			ra.addFlashAttribute("type","success");
			return "redirect:/bookAppointment?type="+type+"&mode="+mode+"&de="+de+"&ye="+email;
		}
		else
		{
			ra.addFlashAttribute("msg","Either Your Email or Password is incorrect!!!");
			return "redirect:/LoginPage/loginForAppointment?type="+type+"&mode="+mode+"&de="+email;
		}
	}
	
	@RequestMapping("/forgetPassword")
	public String forgetPassword(@RequestParam("email") String email)
	{
		return "redirect:/OTPVerification?i=3&ye="+email;
	}
	
	
	
	
}
