package com.das.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MainPageController 
{
	@RequestMapping("/")
	public String home() 
	{
		System.out.println("index.jsp will open....");
		return "index";
	}
	
	@RequestMapping("/LoginPage")
	public String login() 
	{
		System.out.println("LoginPage.jsp will open....");	
		
		return "LoginPage";
	}
	
	@RequestMapping("/LoginPage/loginForAppointment")
	public String loginForAppointment(@RequestParam("type") String type, @RequestParam("mode") String mode, @RequestParam("de") String de, Model m ) 
	{
		System.out.println("LoginPage.jsp will open for appointment booking....");	
		m.addAttribute("type", type);
		m.addAttribute("mode", mode);
		m.addAttribute("de", de);		
		return "LoginPage";
	}
	
	@RequestMapping("/AboutUs")
	public String aboutUs(@RequestParam("type") String type, Model m) 
	{
		System.out.println("AboutUs.jsp will open....");
		m.addAttribute("type", type);
		return "AboutUs";
	}
	
	@RequestMapping("/Emergency")
	public String emergency(@RequestParam("type") String type, Model m) 
	{
		System.out.println("Emergency.jsp will open....");		
		m.addAttribute("type", type);
		return "Emergency 24x7";
	}
	
}
