package com.das.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.das.dao.RegisDAO;

@Controller
public class OTPVerificationPageController 
{
	@Autowired
	private RegisDAO regisDAO;
	
	private String yourOTP, yourEmail, y="";
	
	@RequestMapping("/OTPVerification")	
	public String otp(@RequestParam("i") String i,@RequestParam("ye") String sendTo, Model m)
	{
		System.out.println("OTPVerification.jsp wil open now...");		
		if(i.equals("1"))
		{
			String OTP = this.regisDAO.generateOTP();
			this.regisDAO.sendEmail(sendTo, OTP, "otp verification", null, null);
			this.yourOTP = OTP;
			this.yourEmail = sendTo;
			this.y= i;
			System.out.println("Hello inside the i=1 condition");
		}
		
		if(i.equals("2"))
		{
			m.addAttribute("msg","Wrong OTP!!! Try again.");			
		}
		
		if(i.equals("3"))
		{
			String OTP = this.regisDAO.generateOTP();
			this.regisDAO.sendEmail(sendTo, OTP, "forget password", null, null);
			this.yourOTP = OTP;
			this.yourEmail = sendTo;
			this.y=i;
			System.out.println("Hello inside the i=3 condition");
		}
		
		m.addAttribute("ye",sendTo);
		return "OTPVerification";
	}
	
	@RequestMapping("/OTPValidation")
	public String OTPValidation(@RequestParam("otp") String OTP,Model m)	
	{		
		if(this.yourOTP.equals(OTP))
		{			
			System.out.println("y = "+y);
			if(y.equals("1"))
			{
				System.out.println("update table");
				String msg = regisDAO.updateTblSignin(this.yourEmail);
				m.addAttribute("msg", msg);
				return "LoginPage";
			}
			if(y.equals("3"))
			{
				System.out.println("send password");
				this.regisDAO.sendEmail(this.yourEmail, null, "send password", null, null);
				m.addAttribute("msg", "We have successfully send you an email...");
				return "redirect:/LoginPage";
			}
			else
			{
				return "LoginPage";
			}				
		}
		else 
		{						
			return "redirect:/OTPVerification?i=2&ye="+yourEmail;
		}		
	}
	
}
