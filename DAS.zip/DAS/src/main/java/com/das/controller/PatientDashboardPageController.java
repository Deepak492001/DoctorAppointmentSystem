package com.das.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.das.dao.RegisDAO;
import com.das.model.Appointment;
import com.das.model.DiseaseName;
import com.das.model.UserDetails;

@Controller
public class PatientDashboardPageController 
{
	@Autowired
	private RegisDAO regisDAO;
	
	@RequestMapping("/patientDashboard")
	public String patientDashboard(@RequestParam("ye") String email, Model m)
	{
		m.addAttribute("email",email);
		UserDetails ud = (UserDetails) this.regisDAO.getUserDetails(email);
		List<Appointment> upcoming = this.regisDAO.getUpcomingAppointments(email);
		List<Appointment> past = this.regisDAO.getPastAppointments(email);
		List<DiseaseName> diseaseName = this.regisDAO.getAllDiseaseName();
		m.addAttribute("upca", upcoming);
		m.addAttribute("past", past);
		m.addAttribute("allDiseaseName", diseaseName);	
		m.addAttribute("name", ud.getName());
		m.addAttribute("ye", email);
		return "PatientDashboard";
	}
	
	@RequestMapping("/patientDashboard/appointmentCancellation")
	public String updateStatus(@RequestParam("bookedDate") String date, @RequestParam("ye") String ye)
	{
		this.regisDAO.updateStatus("Cancelled", date);
		return "redirect:/patientDashboard?ye="+ye;
	}
		
	
}
