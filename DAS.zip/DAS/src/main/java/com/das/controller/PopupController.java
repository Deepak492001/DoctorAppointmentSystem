package com.das.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class PopupController 
{
	
	@RequestMapping("/popup_decision")
	public String popup_decision(@RequestParam("radio") String radio)
	{
		if(radio.equals("doctor"))
			return "redirect:/docSignUp";
		else if(radio.equals("patient"))
			return "redirect:/userSignUp";
		else
			return "redirect:/LoginPage";
	}
}
