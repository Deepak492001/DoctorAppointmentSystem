package com.das.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.das.dao.RegisDAO;
import com.das.model.AddDiseaseDetails;

@Controller
public class SearchDiseasePageController 
{ 
	
	@Autowired
	private RegisDAO regisDAO;
	
	@RequestMapping("/showDisease")
	public String showDiseasePage(@RequestParam("disease") String diseaseName, Model model) 
	{
		AddDiseaseDetails details = this.regisDAO.getDiseaseDetails(diseaseName);
		System.out.println("disease name" + diseaseName);
		model.addAttribute("diseasedetails", details);
		return "DiseaseDetails";
	}
}
