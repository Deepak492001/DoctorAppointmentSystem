package com.das.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.das.dao.RegisDAO;
import com.das.model.Cities;
import com.das.model.UserDetails;

@Controller
public class SearchDoctorPageController 
{
	@Autowired
	private RegisDAO regisDAO;
	
	@RequestMapping("/searchDoctor")
	public String searchDoctor(@RequestParam("type") String type, @RequestParam("ye") String ye, Model m)
	{
		System.out.println("SearchDoctor.jsp will open now....");
		ArrayList<String> cities = this.regisDAO.getCities();
		m.addAttribute("cities", cities);
		m.addAttribute("type", type);
		m.addAttribute("ye", ye);
		m.addAttribute("email", ye);
		if(type.equals("dash"))
		{
			UserDetails ud = (UserDetails) this.regisDAO.getUserDetails(ye);
			m.addAttribute("name", ud.getName());
			m.addAttribute("ye", ye);			
		}
		return "SearchDoctor";
	}
	
	@RequestMapping("/searchDoctor/searchByLoc")
	public String searchByLoc(@RequestParam("type") String type, @RequestParam("ye") String ye, @RequestParam("location") String loc, Model m)
	{
		System.out.println("your searched location is : "+loc);
		
		return "redirect:/viewAllDoctor?type="+type+"&location="+loc+"&ye="+ye;
	}
	
	
	
}
