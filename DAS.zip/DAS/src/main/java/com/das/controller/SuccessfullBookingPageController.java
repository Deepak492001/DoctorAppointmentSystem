package com.das.controller;

import org.springframework.cglib.transform.impl.AddDelegateTransformer;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class SuccessfullBookingPageController 
{
	@RequestMapping("/successfullyBooked")
	public String success(@RequestParam("msg") String msg, @RequestParam("ye") String email, Model m)
	{
		m.addAttribute("msg",msg);
		m.addAttribute("ye", email);
		return "SuccessfullBooking";
	}
}
