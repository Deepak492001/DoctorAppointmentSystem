package com.das.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.das.dao.RegisDAO;
import com.das.model.DocAdditionalDetails;
import com.das.model.SignUpDoctor;
import com.das.model.UserDetails;

@Controller
public class ViewAllDoctorPageController 
{
	
	@Autowired
	private RegisDAO regisDAO;
	
	@RequestMapping("/viewAllDoctor")
	public String viewAllDoctor(@RequestParam("type") String type, @RequestParam("location") String location, @RequestParam("ye") String ye, Model m)
	{
		System.out.println("ViewAllDoctor.jsp will open now...");		
		List<DocAdditionalDetails> allDoctor = regisDAO.getAllDoctor(location);
		
		m.addAttribute("location", location);
		m.addAttribute("counting", allDoctor.size());
		m.addAttribute("allDoctor",allDoctor);
		m.addAttribute("type", type);
		m.addAttribute("ye", ye);
		m.addAttribute("email", ye);
		if(type.equals("dash"))
		{
			UserDetails ud = (UserDetails) this.regisDAO.getUserDetails(ye);
			m.addAttribute("name", ud.getName());
		}
		
		return "ViewAllDoctor";
	}
	
	
	
	
}
