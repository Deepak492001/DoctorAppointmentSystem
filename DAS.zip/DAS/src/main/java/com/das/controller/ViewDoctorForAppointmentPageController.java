package com.das.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;


import com.das.dao.RegisDAO;
import com.das.model.DocAdditionalDetails;
import com.das.model.SignUpDoctor;
import com.das.model.UserDetails;

@Controller
public class ViewDoctorForAppointmentPageController 
{
	@Autowired
	private RegisDAO regisDAO;
	
	@RequestMapping("/viewDoctorForAppointment")
	public String viewDoctorForAppointment(@RequestParam("type") String type, @RequestParam("de") String doc_email, @RequestParam("ye") String ye, Model m)
	{
		System.out.println("ViewDoctorForAppointment.jsp will open now...");
		
		SignUpDoctor sud = regisDAO.getDoctorDetails(doc_email);
		DocAdditionalDetails dad = regisDAO.getDocAdditionalDetails(doc_email);
				
		m.addAttribute("work_hidden", sud.getWork_hidden());
		m.addAttribute("edu_hidden", sud.getEdu_hidden());
		m.addAttribute("si_hidden", sud.getSi_hidden());
				
		m.addAttribute("type", type);
		m.addAttribute("email", ye);		
		m.addAttribute("doc_name",dad.getName());
		m.addAttribute("doc_email",dad.getEmail());
		m.addAttribute("designation",dad.getDesignation());
		m.addAttribute("profession",dad.getProfession());
		m.addAttribute("hospital_name",dad.getHospital_name());
		m.addAttribute("location",dad.getLocation());
		m.addAttribute("fees",dad.getFees());
		m.addAttribute("timings",dad.getTimings());
		
		if(type.equals("dash"))
		{
			UserDetails ud = (UserDetails) this.regisDAO.getUserDetails(ye);
			m.addAttribute("name", ud.getName());
			m.addAttribute("ye", ye);			
		}
		
		return "ViewDoctorForAppointment";
	}
}
