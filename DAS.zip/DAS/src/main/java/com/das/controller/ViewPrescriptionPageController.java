package com.das.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.das.dao.RegisDAO;
import com.das.model.ViewPrescription;

@Controller
public class ViewPrescriptionPageController 
{
	
	@Autowired
	private RegisDAO regisDAO;
	
	@RequestMapping("/viewPrescription")
	public String viewPre(@RequestParam("Pid") String pid,Model m)
	{
		ViewPrescription vp = regisDAO.viewPrescription(pid);
		m.addAttribute("vp",vp);
		System.out.println(vp);
		return "ViewPrescription";
	}
}
