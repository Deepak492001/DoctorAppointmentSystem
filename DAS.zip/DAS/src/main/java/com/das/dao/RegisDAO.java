package com.das.dao;

import java.security.Security;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.function.Predicate;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.persistence.criteria.CriteriaQuery;
import javax.transaction.Transactional;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.SessionAttributes;


import com.das.model.AddDiseaseDetails;
import com.das.model.AddDiseaseName;
import com.das.model.Appointment;
import com.das.model.BookAppointment;
import com.das.model.ContactUs;
import com.das.model.DiseaseName;
import com.das.model.DocAdditionalDetails;
import com.das.model.Feedback;
import com.das.model.GeneratePrescription;
import com.das.model.Scheme;
import com.das.model.SignIn;
import com.das.model.SignUpDoctor;
import com.das.model.UserDetails;
import com.das.model.ViewPrescription;


@SuppressWarnings("deprecation")
@Component
@SessionAttributes("session")
public class RegisDAO 
{
	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	@Autowired
	private SessionFactory sessionFactory;
	
	org.hibernate.Session session;
	
	public HibernateTemplate getHibernateTemplate() {
		return hibernateTemplate;
	}

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}
	
	
	@Transactional
	public String docSignUp(SignUpDoctor doc)
	{		
		String email="";
		try
		{
			email = (String) this.hibernateTemplate.save(doc);
			return "Successfully inserted Doctor with email = "+email;
		}
		catch(Exception e)
		{
			return "Sorry something went wrong!!! This "+email+" is already registered with us...";
		}
	}
	
	@Transactional
	public String insertIntoSignIn(SignIn si)
	{
		try 
		{
			this.hibernateTemplate.save(si);
			return "";
		}
		catch(Exception e)
		{
			return "Something went wrong "+e.getMessage();
		}
		
	}
	
	@Transactional
	public SignIn getSignInDetails(String email)
	{
		return this.hibernateTemplate.get(SignIn.class, email);
	}

	@Transactional
	public String addDocAdditionalDetails(DocAdditionalDetails dad) 
	{		
		String email = (String) this.hibernateTemplate.save(dad);
		return email;
	}

	@Transactional
	public SignUpDoctor getDoctorDetails(String email) 
	{
		SignUpDoctor sup = this.hibernateTemplate.get(SignUpDoctor.class, email);
		return sup;
	}

	@Transactional
	public DocAdditionalDetails getDocAdditionalDetails(String email) 
	{
		DocAdditionalDetails dad = this.hibernateTemplate.get(DocAdditionalDetails.class, email);
		return dad;		
	}

	@Transactional
	public List<DocAdditionalDetails> getAllDoctor(String location) 
	{
		this.session = this.sessionFactory.getCurrentSession();
		Criteria criteria = this.session.createCriteria(DocAdditionalDetails.class);
		criteria.add(Restrictions.eq("location", location));		
		List<DocAdditionalDetails> allDoctor = (List<DocAdditionalDetails>) criteria.list();	
		return allDoctor;
	}

	@Transactional
	public String bookAppointment(BookAppointment book) 
	{		
		this.hibernateTemplate.save(book);
		return "Successfully booked....";
	}
	
	public String generateOTP()
	{		
        String otp=""+(int) (Math.random()*100000);
        System.out.println("your otp is:- "+otp);
		return otp;
	}
		
	
	@Transactional
	public String updateTblSignin(String email) 
	{
		String s= String.format("update SignIn set status = '%s' where email = '%s'","verified",email );
		this.session = this.sessionFactory.getCurrentSession();
		Query query = session.createQuery(s);
		int i = query.executeUpdate();
		if(i==1)		
			return "Successfully verified";		
		else
			return "User not found!!!";
	}	

	@Transactional	
	public DocAdditionalDetails getDoctorDetailsForDashboard(String email) 
	{
		DocAdditionalDetails dad = this.hibernateTemplate.get(DocAdditionalDetails.class, email);
		return dad;
	}

	@Transactional
	public int countAppointment(String email, String status)
	{
		this.session = this.sessionFactory.getCurrentSession();
		String s=String.format("select count(*) From BookAppointment where doctorEmail='%s' and status='%s'", email, status);
		Query query = session.createQuery(s);
		Long l = (Long) query.uniqueResult();
		return l.intValue();
		
	}

	@Transactional
	public int countTodayAppointments(String email)
	{
		this.session = this.sessionFactory.getCurrentSession();
		String s=String.format("select count(*) From BookAppointment where doctorEmail='%s' and appointmentDate='%s'", email, new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
		Query query = session.createQuery(s);
		Long l = (Long) query.uniqueResult();
		return l.intValue();
		
	}

	@Transactional
	public int getTotalAppointmentBooked(String email) 
	{
		this.session = this.sessionFactory.getCurrentSession();
		String s = String.format("select count(*) from BookAppointment where doctorEmail='%s'",email);
		Query query = session.createQuery(s);
		Long l = (Long) query.uniqueResult();
		return l.intValue();		
	}

	@SuppressWarnings({ "deprecation", "unchecked" })
	@Transactional
	public List<BookAppointment> getAppointments(String email, String status) 
	{	
		this.session = this.sessionFactory.getCurrentSession();
		
		Criteria criteria = session.createCriteria(BookAppointment.class);
		criteria.add(Restrictions.eq("status", status));
		criteria.add(Restrictions.eq("doctorEmail",email));
		return criteria.list();
				
	}

	@Transactional
	public String updateStatus(String status, String date) 
	{	
		
		this.session = this.sessionFactory.getCurrentSession();
		Criteria criteria = this.session.createCriteria(BookAppointment.class);
		criteria.add(Restrictions.eq("status", "Pending"));
		criteria.add(Restrictions.eq("currentDate", date));
		BookAppointment book = (BookAppointment) criteria.uniqueResult();
		
		String s = String.format("update BookAppointment set status='%s' where bookedDate='%s'", status, date);		
		Query query = session.createQuery(s);
		int i = query.executeUpdate();
				
		if(status.equals("Approved"))		
			this.sendEmail(book.getPatientEmail(), null, "appointment booked", book, "pat");
		else if(status.equals("Cancelled"))
			this.sendEmail(book.getPatientEmail(), null, "appointment cancelled", book, "pat");
		
		if(i==1)
		{
			return "Successfully "+status;
		}
		else
			return "Still Pending...";
	}

	@SuppressWarnings({ "unchecked", "deprecation" })
	@Transactional
	public List<BookAppointment> getPatientDetailsForPrescription(String docEmail, String bookedDate) 
	{ 
		this.session = this.sessionFactory.getCurrentSession();		
		Criteria criteria = session.createCriteria(BookAppointment.class);
		criteria.add(Restrictions.eq("currentDate",bookedDate));
		criteria.add(Restrictions.eq("doctorEmail",docEmail));
		return criteria.list();
	}

	@Transactional
	public int insertPrescription(GeneratePrescription genPre, String bookedDate) 
	{		
		int pid =(Integer) this.hibernateTemplate.save(genPre);
		String s = String.format("update BookAppointment set prescription='%s', status='%s' where bookedDate='%s' ","Pid = "+pid, "Complete", bookedDate);
		this.session = this.sessionFactory.getCurrentSession();
		Query query = session.createQuery(s);
		int i = query.executeUpdate();
		if(i==1)
			return pid;
		else
			return 0;
	}

	@Transactional
	public String uploadLink(String patientEmail, String bookedDate, String platformName, String meetingLink) 
	{		
		String s = String.format("update BookAppointment set link='%s', platformname='%s', meetingLink='%s' where bookedDate='%s' and patientEmail='%s'","Yes", platformName, meetingLink, bookedDate, patientEmail);
		this.session = this.sessionFactory.getCurrentSession();
		Query query = session.createQuery(s);
		int i = query.executeUpdate();
		if(i == 1)
			return "Successfull";
		else
			return "Error";
	}

	@Transactional
	public void updateAppointmentDateAndTime(String email, String bookedDate, String appointmentDate, String appointmentTime) 
	{
		String s = String.format("update BookAppointment set appointmentDate='%s', appointmentTime='%s' where bookedDate='%s' and doctorEmail='%s'", appointmentDate, appointmentTime, bookedDate, email);
		this.session = this.sessionFactory.getCurrentSession();
		Query query = session.createQuery(s);
		query.executeUpdate();
	}

	@Transactional
	public ViewPrescription viewPrescription(String pid)
	{
		String s = String.format("select * from (select a.bookedDate, a.patientName, a.appointmentDate, a.patientMobileNumber, a.patientGender, a.patientAge, a.patientEmail, p.generatedDate, p.medicineDetails, p.pid, d.name, d.email, d.profession, d.location, d.hospital_name as hospitalName, d.timings from tblAppointment a inner join tblPrescription p on a.bookedDate = p.bookedDate inner join tblDocAdditionalDetails d on a.doctorEmail = d.email ) e where e.pid='%s'",pid);
		Query<ViewPrescription> query = this.sessionFactory.getCurrentSession().createNativeQuery(s);		
		query.setResultTransformer(Transformers.aliasToBean(ViewPrescription.class));
		List<ViewPrescription> list = query.list();
		ViewPrescription vp = list.get(0);
		return vp;		
	}
	
	@SuppressWarnings("unchecked")
	@Transactional
	public ArrayList<String> getCities() 
	{
		this.session = this.sessionFactory.getCurrentSession();
		Query query = this.session.createQuery("from Cities");		
		ArrayList<String> cities = (ArrayList<String>) query.list(); 
		return cities;
	}

	@Transactional
	public String updateOPDTimings(String email, String timings) 
	{
		this.session = this.sessionFactory.getCurrentSession();
		String s = String.format("update DocAdditionalDetails set timings='%s' where email='%s'",timings, email);
		Query query = this.session.createQuery(s);
		int i = query.executeUpdate();
		if(i==1)
			return "Successfully update";
		else
			return "Error";
	}

	@Transactional
	public String changePassword(String type, String email, String currPassword, String newPassword) 
	{
		this.session = this.sessionFactory.getCurrentSession();
		String s = String.format("update SignIn set password='%s' where email='%s' and password='%s'", newPassword, email, currPassword);
		if(type.equals("doc"))
		{
			String s1 = String.format("update SignUpDoctor set password='%s' where email='%s'", newPassword, email);
			Query query1 = this.session.createQuery(s);
			Query query2 = this.session.createQuery(s1);
			int i = query1.executeUpdate();
			int y = query2.executeUpdate();
			if(i==1 && y==1)
				return "Your password has been changed successfully....";
			else
				return "Sorry!!! Incorrect password... Try Again Later with correct password..";
		}
		else
		{
			String s1 = String.format("update UserDetails set password='%s' where email='%s'", newPassword, email);
			Query query1 = this.session.createQuery(s);			
			Query query2 = this.session.createQuery(s1);
			int i = query1.executeUpdate();
			int y = query2.executeUpdate();
			if(i==1 && y==1)
				return "Your password has been changed successfully....";
			else
				return "Sorry!!! Incorrect password... Try Again Later with correct password..";
		}		
	}
	
	@Transactional
	public void addDiseaseName(AddDiseaseName adn) 
	{
		this.hibernateTemplate.save(adn);		
	}

	@Transactional
	public List<AddDiseaseName> getAllDisease() 
	{
		List<AddDiseaseName> adn = (List<AddDiseaseName>)this.hibernateTemplate.loadAll(AddDiseaseName.class);
		return adn;
	}

	@Transactional
	public void addDiseaseDetails(AddDiseaseDetails add) 
	{
		this.hibernateTemplate.save(add);		
	}
	
	//	Contact Us	
	@Transactional
	public String addContactUsInfo(ContactUs contactUs) 
	{		
		String msg = (String) this.hibernateTemplate.save(contactUs);
		if (msg.equals(""))
			return "Error something went wrong!!! Try again later...";
		else
			return "Successfully received your request.";
	}

	@Transactional
	public UserDetails getUserDetails(String email) 
	{
		return this.hibernateTemplate.get(UserDetails.class, email);		
	}

	@Transactional
	public String userSignUp(UserDetails ud) 
	{		
		String email="";
		try
		{
			email = (String) this.hibernateTemplate.save(ud);
			return "Successfully registered you with email = "+email;
		}
		catch(Exception e)
		{
			return "Sorry something went wrong!!! This "+email+" is already registered with us...";
		}
	}
	
	@Transactional
	public List<Appointment> getUpcomingAppointments(String patientEmail)
	{
		String query= String.format("select * from (select appoint.patientName,appoint.link,appoint.prescription ,appoint.status,"
	    + " appoint.bookedDate, appoint.appointmentDate, appoint.patientAge, appoint.appointmentTime,"
	    + "    appoint.mode,appoint.patientEmail, appoint.patientGender,  "
	    + " appoint.relation, appoint.doctorEmail, appoint.meetingLink, appoint.platformName, docAdd.name as docName, docAdd.profession "
	    + " from tblAppointment appoint inner join tblDocAdditionalDetails docAdd on appoint.doctorEmail = docAdd.email )"
	    + "    e where e.patientEmail='%s' and (e.status='Approved' or e.status='Pending') ",patientEmail );
	    
 		this.session = this.sessionFactory.getCurrentSession();
		Query query2 = this.session.createNativeQuery(query);
		query2.setResultTransformer(Transformers.aliasToBean(Appointment.class));
		List<Appointment> list = (List<Appointment>) query2.list();			
		return list;
	}
	
	@Transactional
	public List<Appointment> getPastAppointments(String patientEmail)
	{
		String query= String.format("select * from (select appoint.patientName,appoint.link,appoint.prescription ,appoint.status,"
	    + " appoint.bookedDate, appoint.appointmentDate, appoint.patientAge, appoint.appointmentTime,"
	    + "    appoint.mode,appoint.patientEmail, appoint.patientGender,  "
	    + " appoint.relation, appoint.doctorEmail, docAdd.name as docName, docAdd.profession "
	    + " from tblAppointment appoint inner join tblDocAdditionalDetails docAdd on appoint.doctorEmail = docAdd.email )"
	    + "    e where e.patientEmail='%s' and e.status='Complete' or e.status='Cancelled '",patientEmail );
    
 		this.session = this.sessionFactory.getCurrentSession();
		Query query2 = this.session.createNativeQuery(query);
		query2.setResultTransformer(Transformers.aliasToBean(Appointment.class));
		List<Appointment> list = (List<Appointment>) query2.list();			
		return list;
	}

	@Transactional
	public void accountDelete(String type, String email) 
	{
		if(type.equals("doc"))
		{
			String s= String.format("delete from SignIn where email='%s'",email);
			String s1= String.format("delete from SignUpDoctor where email='%s'",email);
			String s2= String.format("delete from DocAdditionalDetails where email='%s'",email);		
					
			this.session = this.sessionFactory.getCurrentSession();
			Query query = this.session.createQuery(s);
			Query query1 = this.session.createQuery(s1);
			Query query2 = this.session.createQuery(s2);
			
			query.executeUpdate();
			query1.executeUpdate();
			query2.executeUpdate();
		}
		else if(type.equals("pat"))
		{
			String s= String.format("delete from SignIn where email='%s'",email);
			String s1= String.format("delete from UserDetails where email='%s'",email);
									
			this.session = this.sessionFactory.getCurrentSession();
			Query query = this.session.createQuery(s);
			Query query1 = this.session.createQuery(s1);			
			
			query.executeUpdate();
			query1.executeUpdate();			
		}
	}

	@Transactional
	public AddDiseaseDetails getDiseaseDetails(String diseaseName) 
	{
        this.session = this.sessionFactory.getCurrentSession();
        Criteria c = this.session.createCriteria(AddDiseaseDetails.class);
        c.add(Restrictions.eq("diseaseName", diseaseName));		
		return (AddDiseaseDetails) c.uniqueResult();
	}

	@Transactional
	public List<DiseaseName> getAllDiseaseName() 
	{
		return this.hibernateTemplate.loadAll(DiseaseName.class);		
	}
	
	@Transactional
	public void sendEmail(String sendTo, String otp, String status, BookAppointment book, String account_type)
	{
		String type = "";
		String name = "";
		try
		{
			String[] EMAILADDR = {sendTo,"princegiri65j@gmail.com"}; 
	        //Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());
	        Properties props = new Properties();
	        props.put("mail.smtp.host", "smtp.gmail.com");
	        props.put("mail.smtp.auth", "true");
	        props.put("mail.debug", "true");
	        props.put("mail.smtp.port", "465");
	        props.put("mail.smtp.socketFactory.port", "465");
	        props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
	        props.put("mail.smtp.socketFactory.fallback", "false");
	        Session ses = Session.getDefaultInstance(props,new javax.mail.Authenticator() 
	        {
	            protected PasswordAuthentication getPasswordAuthentication() 
	            {
	              return new PasswordAuthentication("princegiri.iihs","wlav lout kzmh xddk");//Please Provide The Sender Address
	            }
	        });
	        ses.setDebug(true);
	        Message msgg = new MimeMessage(ses); // Multipurpose Internet Mail Extension 
	        InternetAddress addressFrom = new InternetAddress("princegiri.iihs@gmail.com");
	        msgg.setFrom(addressFrom);
	        InternetAddress[] ADDRESS_TO = new InternetAddress[EMAILADDR.length];
	        for (int y = 0; y < EMAILADDR.length; y++) 
	        {
	           ADDRESS_TO[y] = new InternetAddress(EMAILADDR[y]);
	        }
	        msgg.setRecipients(Message.RecipientType.BCC, ADDRESS_TO);

	        switch(status)
			{
	        	//	Account Verification        
	        	case "otp verification":
	        		SignIn signin = this.getSignInDetails(sendTo);
	        		type = signin.getType();
	        		System.out.println("type = "+type);
	        		if(type.equals("pat"))
	        		{
	        			UserDetails ud = this.getUserDetails(sendTo);
	        			name = ud.getName();
	        		}
	        		else
	        		{
	        			DocAdditionalDetails dad = this.getDocAdditionalDetails(sendTo);
	        			name = dad.getName();
	        		}
	        		System.out.println("subject generating");
	        		msgg.setSubject("Your one time password (OTP) - "+otp);
	        		System.out.println("subject generated");
	        		msgg.setContent("<!DOCTYPE html>\r\n" + 
	        				"<html lang=\"en\">\r\n" + 
	        				"<head>\r\n" + 
	        				"<meta charset=\"UTF-8\">\r\n" + 
	        				"<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">\r\n" + 
	        				"<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n" + 
	        				"<title>email template</title>\r\n" + 
	        				"</head>\r\n" + 
	        				"<body\r\n" + 
	        				"	style=\"background: linear-gradient(to right, rgb(57, 252, 67), rgb(252, 186, 186)); display: flex; align-items: center; justify-content: center;\">\r\n" + 
	        				"\r\n" + 
	        				"	<table\r\n" + 
	        				"		style=\"border: 0; padding: 0; width: 100%; background-color: white;\">\r\n" + 
	        				"		<tbody>\r\n" + 
	        				"			<tr>\r\n" + 
	        				"				<td style=\"align-items: center; justify-content: center;\">\r\n" + 
	        				"\r\n" + 
	        				"					<table style=\"border: 0; width: 100%;\">\r\n" + 
	        				"						<tbody>\r\n" + 
	        				"							<tr>\r\n" + 
	        				"								<td\r\n" + 
	        				"									style=\"background: linear-gradient(to right, rgb(244, 175, 238), rgb(164, 247, 246)); border-radius: 5px; height: 50px;\">\r\n" + 
	        				"									<!-- this is code website name -->\r\n" + 
	        				"									<h1\r\n" + 
	        				"										style=\"text-align: center; color: red; font-family: 'Times New Roman', Times, serif; font-weight: bold; font-size: 40px;\">\r\n" + 
	        				"										DocMeet\r\n" + 
	        				"									</h1>\r\n" + 
	        				"								</td>\r\n" + 
	        				"							</tr>\r\n" + 
	        				"						</tbody>\r\n" + 
	        				"					</table>\r\n" + 
	        				"				</td>\r\n" + 
	        				"			</tr>\r\n" + 
	        				"			<tr>\r\n" + 
	        				"\r\n" + 
	        				"				<td\r\n" + 
	        				"					style=\"display: flex; align-items: center; justify-content: center\">\r\n" + 
	        				"\r\n" + 
	        				"					<!-- this your appointment booked -->\r\n" + 
	        				"					<p\r\n" + 
	        				"						style=\"align-items: center; justify-content: center; font-weight: bold; font-size: 1.5em; letter-spacing: 0.025em; color: rgb(0, 26, 255); padding: 5px; margin: 5px; font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;\">\r\n" + 
	        				"						OTP Verification <br>\r\n" + 
	        				"					</p>\r\n" + 
	        				"				</td>\r\n" + 
	        				"			</tr>\r\n" + 
	        				"\r\n" + 
	        				"			<tr style=\"display: inline-block;\">\r\n" + 
	        				"				<td\r\n" + 
	        				"					style=\"width: 100%; margin-top: 0; border: none; background-color: white;\">\r\n" + 
	        				"					<img\r\n" + 
	        				"					src=\"https://img.freepik.com/free-vector/enter-otp-concept-illustration_114360-7867.jpg?w=900&t=st=1670064484~exp=1670065084~hmac=1dce82a171513ac39353e132b578e50c3e19271f588396f19750353f601a61c6\"\r\n" + 
	        				"					style=\"border: none; justify-content: center; width: 100%; height: 70vh; border-radius: 20px; margin-top: 0%; margin-bottom: 0%\" />\r\n" + 
	        				"\r\n" + 
	        				"\r\n" + 
	        				"					<!-- this is code for user Name -->\r\n" + 
	        				"					<p\r\n" + 
	        				"						style=\"color: black; font-size: 25px; text-align: left; align-items: center; margin-top: 0%\">\r\n" + 
	        				"Dear "+ name +",\r\n" + 
	        				"					</p> \r\n" + 
	        				"						<!-- this is code for instruction -->\r\n" + 
	        				"					<p class=\"data\"\r\n" + 
	        				"						style=\"text-align: justify-all; align-items: center; font-size: 1.2em; font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif; padding-bottom: 12px; margin: 0.65rem\">\r\n" + 
	        				"						Thank you for chossing DocMeet. Use this OTP(One Time Password) to\r\n" + 
	        				"						complete your signUp procedures and verify your account on\r\n" + 
	        				"						DocMeet. this OTP(One Time Password) will expire in 15 minutes.\r\n" + 
	        				"					</p> \r\n" + 
	        				"						<!-- this span section for otp number -->\r\n" + 
	        				"					<span\r\n" + 
	        				"						style=\"display: block; background-color: rgb(0, 255, 68); margin: 0 auto; align-items: center; color: black; width: fit-content; text-align: center; padding: 10px; font-size: 2rem; font-weight: bold; letter-spacing: 0.25rem; border-radius: 20px;\">\r\n" + 
	        				"						"+otp+" \r\n" + 
	        				"					</span>\r\n" + 
	        				"					<p class=\"data\"\r\n" + 
	        				"						style=\"text-align: justify-all; align-items: center; font-size: 1em; margin-top: 10px; font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif; padding-bottom: 12px; margin: 0.65rem\">\r\n" + 
	        				"						* Remember , Never share this OTP with anyone, not even if DocMeet\r\n" + 
	        				"						ask to you.\r\n" + 
	        				"					</p> \r\n" + 
	        				"					<span\r\n" + 
	        				"					style=\"font-size: 1.2em; font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif; padding-bottom: 12px; margin: 0.65rem\">Thanks\r\n" + 
	        				"						& Regards\r\n" + 
	        				"					</span><br> \r\n" + 
	        				"					<span\r\n" + 
	        				"					style=\"font-size: 1.2em; font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif; padding-bottom: 12px; margin: 0.65rem\">DocMeet\r\n" + 
	        				"						Team\r\n" + 
	        				"					</span>\r\n" + 
	        				"				</td>\r\n" + 
	        				"			</tr>\r\n" + 
	        				"			<tr\r\n" + 
	        				"				style=\"border: none; background-color: #ffd737; height: 40px; color: white; padding-bottom: 20px; text-align: center;\">\r\n" + 
	        				"\r\n" + 
	        				"				<td>\r\n" + 
	        				"					<p\r\n" + 
	        				"						style=\"color: rgb(10, 0, 0); line-height: 1.5em; font-size: 2rem; font-weight: bold\">\r\n" + 
	        				"						DocMeet</p> <a href=\"#\"\r\n" + 
	        				"					style=\"border: none; text-decoration: none; padding: 5px;\"> <img\r\n" + 
	        				"						src=\"https://icones.pro/wp-content/uploads/2021/02/icone-twitter-violet.png\"\r\n" + 
	        				"						alt=\"Image not found\" style=\"width: 30px; height: 30px;\" />\r\n" + 
	        				"				</a> <a href=\"#\"\r\n" + 
	        				"					style=\"border: none; text-decoration: none; padding: 5px;\"> <img\r\n" + 
	        				"						src=\"https://i.pinimg.com/originals/d2/97/9b/d2979bd98ea37dd3ba4d31c20828ceed.png\"\r\n" + 
	        				"						style=\"width: 30px; height: 30px;\" />\r\n" + 
	        				"				</a> <a href=\"#\"\r\n" + 
	        				"					style=\"border: none; text-decoration: none; padding: 5px;\"> <img\r\n" + 
	        				"						src=\"https://png.pngtree.com/png-clipart/20180626/ourmid/pngtree-instagram-icon-instagram-logo-png-image_3584852.png\"\r\n" + 
	        				"						style=\"width: 30px; height: 30px; position: relative; padding-bottom: 0%;\" />\r\n" + 
	        				"				</a>\r\n" + 
	        				"				</td>\r\n" + 
	        				"			</tr>\r\n" + 
	        				"			<tr>\r\n" + 
	        				"				<td\r\n" + 
	        				"					style=\"text-align: center; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; font-size: 11px; line-height: 18px; color: #393636;\">\r\n" + 
	        				"					<a href=\"#\" target=\"_blank\"\r\n" + 
	        				"					style=\"color: #999999; text-decoration: underline;\">PRIVACY\r\n" + 
	        				"						STATEMENT</a> | <a href=\"#\" target=\"_blank\"\r\n" + 
	        				"					style=\"color: #999999; text-decoration: underline;\">TERMS OF\r\n" + 
	        				"						SERVICE</a> | <a href=\"#\" target=\"_blank\"\r\n" + 
	        				"					style=\"color: #999999; text-decoration: underline;\">RETURNS</a><br>\r\n" + 
	        				"					� 2022 DocMeet. All Rights Reserved.<br> If you do not wish to\r\n" + 
	        				"					receive any further emails from us, please <a href=\"#\"\r\n" + 
	        				"					target=\"_blank\" style=\"text-decoration: none; color: #f51919;\">unsubscribe</a>\r\n" + 
	        				"				</td>\r\n" + 
	        				"			</tr>\r\n" + 
	        				"		</tbody>\r\n" + 
	        				"	</table>\r\n" + 
	        				"</body>\r\n" + 
	        				"</html>","text/html");
	        		Transport.send(msgg);
	        		System.out.println("OTP send successfully");	        		
	        		
	        		break;
	        	
        		// Appointment Booked
	        	case "appointment approved":
	        		UserDetails ud2 = this.getUserDetails(sendTo);	        		
        			DocAdditionalDetails dad2 = this.getDocAdditionalDetails(book.getDoctorEmail());
        			
	        		break;
	        		
    			// Appointment Approved 	        	
	        	case "appointment booked":	        		
        			UserDetails ud3 = this.getUserDetails(sendTo);	        		
        			DocAdditionalDetails dad3 = this.getDocAdditionalDetails(book.getDoctorEmail());
	        		msgg.setSubject("Your appointment with Dr. "+dad3.getName()+" has been booked");
	        		msgg.setContent("<!DOCTYPE html>\r\n" + 
	        				"<html lang=\"en\">\r\n" + 
	        				"<head>\r\n" + 
	        				"<meta charset=\"UTF-8\">\r\n" + 
	        				"<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">\r\n" + 
	        				"<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n" + 
	        				"<title>email template</title>\r\n" + 
	        				"</head>\r\n" + 
	        				"<body style=\"background: linear-gradient(to right, rgb(57, 252, 67), rgb(252, 186, 186)); display: flex; align-items: center; justify-content: center;\">\r\n" + 
	        				"<table style=\"border: 0; padding: 0; width: 100%; background-color: white;\">\r\n" + 
	        				"	<tbody>\r\n" + 
	        				"		<tr>\r\n" + 
	        				"			<td style=\"align-items: center; justify-content: center;\">\r\n" + 
	        				"				<table style=\"border: 0; width: 100%;\">\r\n" + 
	        				"					<tbody>\r\n" + 
	        				"						<tr>\r\n" + 
	        				"							<td style=\"background-color:rgb(245, 245, 245); border-radius: 5px; height: 50px;\">\r\n" + 
	        				"								 <!-- this is code website name -->\r\n" + 
	        				"								<h1 style=\"text-align: center;black: white;font-weight:900; font-family: 'Times New Roman', Times, serif; font-weight: bold; font-size: 40px;\"><img src=\"101.png\" alt=\"image not found\" style=\"width: 50px\"/>DocMeet</h1>\r\n" + 
	        				"							</td>\r\n" + 
	        				"						</tr>\r\n" + 
	        				"					</tbody>\r\n" + 
	        				"				</table>\r\n" + 
	        				"			</td>\r\n" + 
	        				"		</tr>\r\n" + 
	        				"		<tr style=\"display: inline-block;\">\r\n" + 
	        				"			<td style=\"width: 100%; margin-top: 0; border: none; background-color: white;\">\r\n" + 
	        				"				<img src=\"https://img.freepik.com/free-vector/businessman-planning-events-deadlines-agenda_74855-6274.jpg?w=740&t=st=1670490908~exp=1670491508~hmac=446edb3e40c543918ad5c32c64785a1ee44768bea0c8d62dcfcbc0eb3eb6b7ff\"alt=\"image not found\"style=\"border: none; justify-content: center; width: 100%; height: 70vh; border-radius: 20px; margin-top: 0%; margin-bottom: 0%\" />\r\n" + 
	        				"				 <!-- this is code for Patient Name -->\r\n" + 
	        				"				<p style=\"color: blue; font-size: 35px; text-align: left; align-items: center; margin-top: 0%\"> Dear "+ud3.getName()+" ,</p> \r\n" + 
	        				"				 <!-- this is code for appointment information -->\r\n" + 
	        				"				<p class=\"data\"style=\"text-align: justify-all; align-items: center; font-size: 1.2em; font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif; padding-bottom: 12px; margin: 0.65rem\">We have successfully scheduled your appointment with <span style=\"font-weight: bold; color: #f90f0f\"> Dr."+dad3.getName()+"</span> on \r\n" +  
	        				"				<span style=\"font-weight: bold;\">"+book.getAppointmentDate()+" between "+book.getAppointmentTime()+"</span> time slot. \r\n" + 	        				
	        				"				Current status of your appointment is : \r\n" + 
	        				"				<span style=\"font-weight: bold; color: red\">Pending .</span><br>\r\n" + 
	        				"					After approval from the doctor your final appointment details will\r\n" + 
	        				"					be send to you. <br>This appointment will be a video consultation.\r\n" + 
	        				"				</p>\r\n" + 
	        				"			</td>\r\n" + 
	        				"		</tr>\r\n" + 
	        				"		<tr style=\"border: none; background-color: #ffd737; height: 40px; color: white; padding-bottom: 20px; text-align: center;\">\r\n" + 
	        				"			<td>\r\n" + 
	        				"				<p style=\"color: rgb(10, 0, 0); line-height: 1.5em; font-size: 2rem; font-weight: bold\">DocMeet</p> \r\n" + 
	        				"				<a href=\"#\"style=\"border: none; text-decoration: none; padding: 5px;\"> <img src=\"https://icones.pro/wp-content/uploads/2021/02/icone-twitter-violet.png\"alt=\"Image not found\" style=\"width: 30px; height: 30px;\" /></a> \r\n" + 
	        				"				<a href=\"#\"style=\"border: none; text-decoration: none; padding: 5px;\"> <img src=\"https://i.pinimg.com/originals/d2/97/9b/d2979bd98ea37dd3ba4d31c20828ceed.png\"style=\"width: 30px; height: 30px;\" /></a> \r\n" + 
	        				"				<a href=\"#\"style=\"border: none; text-decoration: none; padding: 5px;\"> <img src=\"https://png.pngtree.com/png-clipart/20180626/ourmid/pngtree-instagram-icon-instagram-logo-png-image_3584852.png\"style=\"width: 30px; height: 30px; position: relative; padding-bottom: 0%;\" /></a>\r\n" + 
	        				"			</td>\r\n" + 
	        				"		</tr>\r\n" + 
	        				"		<tr>\r\n" + 
	        				"			<td style=\"text-align: center; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; font-size: 11px; line-height: 18px; color: #393636;\">\r\n" + 
	        				"				<a href=\"#\" target=\"_blank\"style=\"color: #999999; text-decoration: underline;\">PRIVACY STATEMENT</a> | \r\n" + 
	        				"				<a href=\"#\" target=\"_blank\"style=\"color: #999999; text-decoration: underline;\">TERMS OF SERVICE</a> | \r\n" + 
	        				"				<a href=\"#\" target=\"_blank\"style=\"color: #999999; text-decoration: underline;\">RETURNS</a><br>� 2022 DocMeet. All Rights Reserved.<br> If you do not wish to receive any further emails from us, please \r\n" + 
	        				"				<a href=\"#\"target=\"_blank\" style=\"text-decoration: none; color: #f51919;\">unsubscribe</a>\r\n" + 
	        				"			</td>\r\n" + 
	        				"		</tr>\r\n" + 
	        				"	</tbody>\r\n" + 
	        				"</table>\r\n" + 
	        				"</body>\r\n" + 
	        				"</html>","text/html");
	        		Transport.send(msgg);
	        		System.out.println("Appointment booked email sent...");

	        		break;
	        		
        		//Forget Password
	        	case "forget password":
	        		signin = this.getSignInDetails(sendTo);
	        		type = signin.getType();
	        		if(type.equals("pat"))
	        		{
	        			UserDetails ud4 = this.getUserDetails(sendTo);
	        			name = ud4.getName();
	        		}
	        		else
	        		{
	        			DocAdditionalDetails dad4 = this.getDocAdditionalDetails(sendTo);
	        			name = dad4.getName();
	        		}
	        		msgg.setSubject("Reset your password");
	        		msgg.setContent("<!DOCTYPE html>\r\n" + 
	        				"<html lang=\"en\">\r\n" + 
	        				"<head>\r\n" + 
	        				"<meta charset=\"UTF-8\">\r\n" + 
	        				"<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">\r\n" + 
	        				"<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n" + 
	        				"<title>email template</title>\r\n" + 
	        				"</head>\r\n" + 
	        				"<body style=\"background: linear-gradient(to right, rgb(57, 252, 67), rgb(252, 186, 186)); display: flex; align-items: center; justify-content: center;\">\r\n" + 
	        				"	<table style=\"border: 0; padding: 0; width: 100%; background-color: white;\">\r\n" + 
	        				"		<tbody>\r\n" + 
	        				"			<tr>\r\n" + 
	        				"				<td style=\"align-items: center; justify-content: center;\">\r\n" + 
	        				"					<table style=\"border: 0; width: 100%;\">\r\n" + 
	        				"						<tbody>\r\n" + 
	        				"							<tr>\r\n" + 
	        				"								<td\r\n" + 
	        				"									style=\"background-color:rgb(245, 245, 245); border-radius: 5px; height: 50px;\">\r\n" + 
	        				"									<!-- this is code website name -->\r\n" + 
	        				"									<h1 style=\"text-align: center; color:black;font-weight:900; font-family: 'Times New Roman', Times, serif; font-weight: bold; font-size: 40px;\"><img src=\"101.png\" alt=\"not\" style=\"width: 50px\"/> DocMeet</h1>\r\n" + 
	        				"								</td>\r\n" + 
	        				"							</tr>\r\n" + 
	        				"						</tbody>\r\n" + 
	        				"					</table>\r\n" + 
	        				"				</td>\r\n" + 
	        				"			</tr>\r\n" + 
	        				"			<tr>\r\n" + 
	        				"				<td style=\"display: flex; align-items: center; justify-content: center\">\r\n" + 
	        				"					<!-- this your appointment booked -->\r\n" + 
	        				"					<p style=\"align-items: center; justify-content: center; font-weight: bold; font-size: 1.5em; letter-spacing: 0.025em; color: rgb(0, 26, 255); padding: 5px; margin: 5px; font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;\">Forget Password <br></p>\r\n" + 
	        				"				</td>\r\n" + 
	        				"			</tr>\r\n" + 
	        				"\r\n" + 
	        				"			<tr style=\"display: inline-block;\">\r\n" + 
	        				"				<td style=\"width: 100%; margin-top: 0; border: none; background-color: white;\">\r\n" + 
	        				"					<img src=\"https://img.freepik.com/premium-vector/forgot-password-account-login-web-page-protection-security-key-access-system-smartphone-computer-flat-vector-illustration_2175-1386.jpg?w=826\" style=\"border: none; justify-content: center; width: 100%; height: 70vh; border-radius: 20px; margin-top: 0%; margin-bottom: 0%\" />\r\n" + 
	        				"					<!-- this is code for user Name -->\r\n" + 
	        				"					<p style=\"color: black; font-size: 25px; text-align: left; align-items: center; margin-top: 0%\">Dear "+name+",</p> <!-- this is code for instruction -->\r\n" + 
	        				"					<p class=\"data\"style=\"text-align: justify-all; align-items: center; font-size: 1.2em; font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif; padding-bottom: 12px; margin: 0.65rem\">We received a request to reset your password. If you didn't make this request, simply ignore this email. this OTP(One Time Password) will expire in 15 minutes.</p> <!-- this span section for otp number -->\r\n" + 
	        				"					<span style=\"display: block; background-color: rgb(16, 16, 16); margin: 0 auto; align-items: center; color: white; width: fit-content; text-align: center; padding: 10px; font-size: 2rem; font-weight: bold; letter-spacing: 0.25rem; border-radius: 20px;\">"+otp+"</span>\r\n" + 
	        				"					<p class=\"data\" style=\"text-align: justify-all; align-items: center; font-size: 1em; margin-top: 10px; font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif; padding-bottom: 12px; margin: 0.65rem\">* Remember , Never share this OTP with anyone, not even if DocMeet ask to you.</p>\r\n" + 
	        				"				</td>\r\n" + 
	        				"			</tr>\r\n" + 
	        				"			<tr style=\"border: none; background-color: #ffd737; height: 40px; color: white; padding-bottom: 20px; text-align: center;\">\r\n" + 
	        				"				<td>\r\n" + 
	        				"					<p style=\"color: rgb(10, 0, 0); line-height: 1.5em; font-size: 2rem; font-weight: bold\">DocMeet</p>\r\n" + 
	        				"					 <a href=\"#\" style=\"border: none; text-decoration: none; padding: 5px;\"> <img src=\"https://icones.pro/wp-content/uploads/2021/02/icone-twitter-violet.png\" alt=\"Image not found\" style=\"width: 30px; height: 30px;\" />\r\n" + 
	        				"				</a> <a href=\"#\" style=\"border: none; text-decoration: none; padding: 5px;\"> <img src=\"https://i.pinimg.com/originals/d2/97/9b/d2979bd98ea37dd3ba4d31c20828ceed.png\"style=\"width: 30px; height: 30px;\" />\r\n" + 
	        				"				</a> <a href=\"#\" style=\"border: none; text-decoration: none; padding: 5px;\"> <img src=\"https://png.pngtree.com/png-clipart/20180626/ourmid/pngtree-instagram-icon-instagram-logo-png-image_3584852.png\"style=\"width: 30px; height: 30px; position: relative; padding-bottom: 0%;\" /></a>\r\n" + 
	        				"				</td>\r\n" + 
	        				"			</tr>\r\n" + 
	        				"			<tr>\r\n" + 
	        				"				<td style=\"text-align: center; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; font-size: 11px; line-height: 18px; color: #393636;\">\r\n" + 
	        				"					<a href=\"#\" target=\"_blank\"style=\"color: #999999; text-decoration: underline;\">PRIVACYSTATEMENT</a> | \r\n" + 
	        				"					<a href=\"#\" target=\"_blank\"style=\"color: #999999; text-decoration: underline;\">TERMS OF SERVICE</a> | \r\n" + 
	        				"					<a href=\"#\" target=\"_blank\"style=\"color: #999999; text-decoration: underline;\">RETURNS</a><br>� 2022 DocMeet. All Rights Reserved.<br> If you do not wish to receive any further emails from us, please \r\n" + 
	        				"					<a href=\"#\"target=\"_blank\" style=\"text-decoration: none; color: #f51919;\">unsubscribe</a>\r\n" + 
	        				"				</td>\r\n" + 
	        				"			</tr>\r\n" + 
	        				"		</tbody>\r\n" + 
	        				"	</table>\r\n" + 
	        				"</body>\r\n" + 
	        				"</html>","text/html");
	        		Transport.send(msgg);
	        		System.out.println("Forget password otp send=t...");	        		
	        		break;
	        	
        		// Account Delete
	        	case "account delete":
	        		System.out.println("account delete case");
	        		if(account_type.equals("pat"))
	        		{
	        			UserDetails ud5 = this.getUserDetails(sendTo);
	        			name = ud5.getName();
	        			System.out.println("patient name = "+name);
	        		}
	        		else
	        		{
	        			DocAdditionalDetails dad5 = this.getDocAdditionalDetails(sendTo);
	        			name = dad5.getName();
	        			System.out.println("doctor name = "+name);
	        		}
	        		msgg.setSubject("Your account has been deleted");
	        		msgg.setContent("<!DOCTYPE html>\r\n" + 
	        				"<html lang=\"en\">\r\n" + 
	        				"<head>\r\n" + 
	        				"<meta charset=\"UTF-8\">\r\n" + 
	        				"<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">\r\n" + 
	        				"<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n" + 
	        				"<title>email template</title>\r\n" + 
	        				"</head>\r\n" + 
	        				"<body style=\"background: linear-gradient(to right, rgb(57, 252, 67), rgb(252, 186, 186)); display: flex; align-items: center; justify-content: center;\">\r\n" + 
	        				"	<table style=\"border: 0; padding: 0; width: 100%; background-color: white;\">\r\n" + 
	        				"		<tbody>\r\n" + 
	        				"			<tr>\r\n" + 
	        				"				<td style=\"align-items: center; justify-content: center;\">\r\n" + 
	        				"					<table style=\"border: 0; width: 100%;\">\r\n" + 
	        				"						<tbody>\r\n" + 
	        				"							<tr>\r\n" + 
	        				"								<td style=\"background-color:rgb(245, 245, 245); border-radius: 5px; height: 50px;\">\r\n" + 
	        				"									<!-- this is code website name -->\r\n" + 
	        				"									<h1 style=\"text-align: center; color:black;font-weight:900; font-family: 'Times New Roman', Times, serif; font-weight: bold; font-size: 40px;\"><img src=\"101.png\" alt=\"not\" style=\"width: 50px\"/>DocMeet</h1>\r\n" + 
	        				"								</td>\r\n" + 
	        				"							</tr>\r\n" + 
	        				"						</tbody>\r\n" + 
	        				"					</table>\r\n" + 
	        				"				</td>\r\n" + 
	        				"			</tr>\r\n" + 
	        				"			<tr>\r\n" + 
	        				"				<td style=\"display: flex; align-items: center; justify-content: center\">\r\n" + 
	        				"					<!-- this your appointment booked -->\r\n" + 
	        				"					<p style=\"align-items: center; justify-content: center; font-weight: bold; font-size: 1.5em; letter-spacing: 0.025em; color: rgb(0, 26, 255); padding: 5px; margin: 5px; font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;\">Account Delete <br></p>\r\n" + 
	        				"				</td>\r\n" + 
	        				"			</tr>\r\n" + 
	        				"			<tr style=\"display: inline-block;\">\r\n" + 
	        				"				<td style=\"width: 100%; margin-top: 0; border: none; background-color: white;\">\r\n" + 
	        				"					<img src=\"https://img.freepik.com/premium-vector/user-deleting-social-account-waste-bin-conceptual-design-premium-vector_199064-106.jpg?w=740\"style=\"border: none; justify-content: center; width: 100%; height: 70vh; border-radius: 20px; margin-top: 0%; margin-bottom: 0%\" />\r\n" + 
	        				"					<!-- this is code for user Name -->\r\n" + 
	        				"					<p style=\"color: black; font-size: 25px; text-align: left; align-items: center; margin-top: 0%\">Dear "+name+",</p> \r\n" + 
	        				"						<!-- this is code for instruction -->\r\n" + 
	        				"					<p class=\"data\"style=\"text-align: justify-all; align-items: center; font-size: 1.2em; font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif; padding-bottom: 12px; margin: 0.65rem\">Your account was deleted successfully. All your data was removed from our database. Thank you for using DocMeet.<br>You can again signup our website through bellow button or go to website.</p> \r\n" + 
	        				"						<!-- this span section for otp number -->\r\n" + 
	        				"					<a href=\"signup\" style=\"display: block; background-color: rgb(0, 255, 68); margin: 0 auto; align-items: center; color: black; width: fit-content; text-align: center; padding: 10px; font-size: 2rem; font-weight: bold; letter-spacing: 0.1rem; border-radius: 20px;text-decoration: none;\">SignUp </a>\r\n" + 
	        				"				</td>\r\n" + 
	        				"			</tr>\r\n" + 
	        				"			<tr style=\"border: none; background-color: #ffd737; height: 40px; color: white; padding-bottom: 20px; text-align: center;\">\r\n" + 
	        				"				<td>\r\n" + 
	        				"					<p style=\"color: rgb(10, 0, 0); line-height: 1.5em; font-size: 2rem; font-weight: bold\">DocMeet</p> \r\n" + 
	        				"					<a href=\"#\"style=\"border: none; text-decoration: none; padding: 5px;\"> <img src=\"https://icones.pro/wp-content/uploads/2021/02/icone-twitter-violet.png\"alt=\"Image not found\" style=\"width: 30px; height: 30px;\" /></a> \r\n" + 
	        				"					<a href=\"#\"style=\"border: none; text-decoration: none; padding: 5px;\"> <img src=\"https://i.pinimg.com/originals/d2/97/9b/d2979bd98ea37dd3ba4d31c20828ceed.png\"style=\"width: 30px; height: 30px;\" /></a> \r\n" + 
	        				"					<a href=\"#\"style=\"border: none; text-decoration: none; padding: 5px;\"> <img src=\"https://png.pngtree.com/png-clipart/20180626/ourmid/pngtree-instagram-icon-instagram-logo-png-image_3584852.png\"style=\"width: 30px; height: 30px; position: relative; padding-bottom: 0%;\" /></a>\r\n" + 
	        				"				</td>\r\n" + 
	        				"			</tr>\r\n" + 
	        				"			<tr>\r\n" + 
	        				"				<td style=\"text-align: center; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; font-size: 11px; line-height: 18px; color: #393636;\">\r\n" + 
	        				"					<a href=\"#\" target=\"_blank\" style=\"color: #999999; text-decoration: underline;\">PRIVACY STATEMENT</a> | \r\n" + 
	        				"					<a href=\"#\" target=\"_blank\"style=\"color: #999999; text-decoration: underline;\">TERMS OF SERVICE</a> | \r\n" + 
	        				"					<a href=\"#\" target=\"_blank\" style=\"color: #999999; text-decoration: underline;\">RETURNS</a><br>� 2022 DocMeet. All Rights Reserved.<br> If you do not wish to receive any further emails from us, please.\r\n" + 
	        				"					<a href=\"#\"target=\"_blank\" style=\"text-decoration: none; color: #f51919;\">unsubscribe</a>\r\n" + 
	        				"				</td>\r\n" + 
	        				"			</tr>\r\n" + 
	        				"		</tbody>\r\n" + 
	        				"	</table>\r\n" + 
	        				"</body>\r\n" + 
	        				"</html>","text/html");
	        		Transport.send(msgg);
	        		System.out.println("Account delete email sent...");
	        		break;
	        	
	        	case "appointment cancelled":        			        			        		
        			msgg.setSubject("Appointment cancelled by you");
	        		msgg.setContent("<html lang=\"en\">\r\n" + 
	        				"<head>\r\n" + 
	        				"<meta charset=\"UTF-8\">\r\n" + 
	        				"<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">\r\n" + 
	        				"<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n" + 
	        				"<title>email template</title>\r\n" + 
	        				"</head>\r\n" + 
	        				"<body style=\"background: linear-gradient(to right, rgb(57, 252, 67), rgb(252, 186, 186)); display: flex; align-items: center; justify-content: center;\">\r\n" + 
	        				"	<table style=\"border: 0; padding: 0; width: 100%; background-color: white;\">\r\n" + 
	        				"		<tbody>\r\n" + 
	        				"			<tr>\r\n" + 
	        				"				<td style=\"align-items: center; justify-content: center;\">\r\n" + 
	        				"					<table style=\"border: 0; width: 100%;\">\r\n" + 
	        				"						<tbody>\r\n" + 
	        				"							<tr>\r\n" + 
	        				"								<td style=\"background-color:rgb(245, 245, 245); border-radius: 5px; height: 50px;\">\r\n" + 
	        				"									<!-- this is code website name -->\r\n" + 
	        				"									<h1 style=\"text-align: center; color:black;font-weight:900; font-family: 'Times New Roman', Times, serif; font-weight: bold; font-size: 40px;\"><img src=\"101.png\" alt=\"not\" style=\"width: 50px\"/>DocMeet</h1>\r\n" + 
	        				"								</td>\r\n" + 
	        				"							</tr>\r\n" + 
	        				"						</tbody>\r\n" + 
	        				"					</table>\r\n" + 
	        				"				</td>\r\n" + 
	        				"			</tr>\r\n" + 
	        				"			<tr>\r\n" + 
	        				"				<td style=\"display: flex; align-items: center; justify-content: center\">\r\n" + 
	        				"					<!-- this your appointment booked -->\r\n" + 
	        				"					<p style=\"align-items: center; justify-content: center; font-weight: bold; font-size: 1.5em; letter-spacing: 0.025em; color: rgb(0, 26, 255); padding: 5px; margin: 5px; font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;\">Appointment Cancelled <br></p>\r\n" + 
	        				"				</td>\r\n" + 
	        				"			</tr>\r\n" + 
	        				"			<tr style=\"display: inline-block;\">\r\n" + 
	        				"				<td style=\"width: 100%; margin-top: 0; border: none; background-color: white;\">\r\n" + 
	        				"					<!-- this is code for user Name -->\r\n" + 
	        				"					<p style=\"color: black; font-size: 25px; text-align: left; align-items: center; margin-top: 0%\">Dear "+book.getPatientName()+",</p> \r\n" + 
	        				"						<!-- this is code for instruction -->\r\n" + 
	        				"					<p class=\"data\"style=\"text-align: justify-all; align-items: center; font-size: 1.2em; font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif; padding-bottom: 12px; margin: 0.65rem\">Your appointment with Dr. "+this.getDocAdditionalDetails(book.getDoctorEmail()).getName()+" on "+book.getAppointmentDate()+" between "+book.getAppointmentTime()+" has been cancelled by you. Status of your appointment at the time of cancelation is :"+book.getStatus()+" </p> \r\n" + 
	        				"					<!-- this span section for otp number -->\r\n" + 
	        				"					<a href=\"#\" style=\"display: block; background-color: rgb(14, 14, 14); margin: 0 auto; align-items: center; color: white; width: fit-content; text-align: center; padding: 10px; font-size: 1rem; font-weight: bold; border-radius: 20px;text-decoration: none;\">Book Appointment </a>\r\n" + 
	        				"					<span style=\"font-size: 1.2em; font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif; padding-bottom: 12px; margin: 0.65rem\">Thanks & Regards</span><br> \r\n" + 
	        				"					<span style=\"font-size: 1.2em; font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif; padding-bottom: 12px; margin: 0.65rem\">DocMeet Team</span>\r\n" + 
	        				"				</td>\r\n" + 
	        				"			</tr>\r\n" + 
	        				"			<tr style=\"border: none; background-color: #ffd737; height: 40px; color: white; padding-bottom: 20px; text-align: center;\">\r\n" + 
	        				"				<td>\r\n" + 
	        				"					<p style=\"color: rgb(10, 0, 0); line-height: 1.5em; font-size: 2rem; font-weight: bold\">DocMeet</p> \r\n" + 
	        				"					<a href=\"#\"style=\"border: none; text-decoration: none; padding: 5px;\"> <img src=\"https://icones.pro/wp-content/uploads/2021/02/icone-twitter-violet.png\"alt=\"Image not found\" style=\"width: 30px; height: 30px;\" /></a> \r\n" + 
	        				"					<a href=\"#\"style=\"border: none; text-decoration: none; padding: 5px;\"> <img src=\"https://i.pinimg.com/originals/d2/97/9b/d2979bd98ea37dd3ba4d31c20828ceed.png\"style=\"width: 30px; height: 30px;\" /></a> \r\n" + 
	        				"					<a href=\"#\"style=\"border: none; text-decoration: none; padding: 5px;\"> <img src=\"https://png.pngtree.com/png-clipart/20180626/ourmid/pngtree-instagram-icon-instagram-logo-png-image_3584852.png\"style=\"width: 30px; height: 30px; position: relative; padding-bottom: 0%;\" /></a>\r\n" + 
	        				"				</td>\r\n" + 
	        				"			</tr>\r\n" + 
	        				"			<tr>\r\n" + 
	        				"				<td style=\"text-align: center; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; font-size: 11px; line-height: 18px; color: #393636;\">\r\n" + 
	        				"					<a href=\"#\" target=\"_blank\" style=\"color: #999999; text-decoration: underline;\">PRIVACY STATEMENT</a> | \r\n" + 
	        				"					<a href=\"#\" target=\"_blank\"style=\"color: #999999; text-decoration: underline;\">TERMS OF SERVICE</a> | \r\n" + 
	        				"					<a href=\"#\" target=\"_blank\" style=\"color: #999999; text-decoration: underline;\">RETURNS</a><br>� 2022 DocMeet. All Rights Reserved.<br> If you do not wish to receive any further emails from us, please.\r\n" + 
	        				"					<a href=\"#\"target=\"_blank\" style=\"text-decoration: none; color: #f51919;\">unsubscribe</a>\r\n" + 
	        				"				</td>\r\n" + 
	        				"			</tr>\r\n" + 
	        				"		</tbody>\r\n" + 
	        				"	</table>\r\n" + 
	        				"</body>\r\n" + 
	        				"</html>", "text/html"); 
	        		
					Transport.send(msgg);
	        		System.out.println("Account delete email sent...");
	        		break;
	        	
	        	case "send password":
	        		signin = this.getSignInDetails(sendTo);	        		
	        		msgg.setSubject("Your DocMeet account password");
	        		msgg.setContent("<!DOCTYPE html>\r\n" + 
	        				"<html lang=\"en\">\r\n" + 
	        				"<head>\r\n" + 
	        				"<meta charset=\"UTF-8\">\r\n" + 
	        				"<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">\r\n" + 
	        				"<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n" + 
	        				"<title>email template</title>\r\n" + 
	        				"</head>\r\n" + 
	        				"<body style=\"background: linear-gradient(to right, rgb(57, 252, 67), rgb(252, 186, 186)); display: flex; align-items: center; justify-content: center;\">\r\n" + 
	        				"	<table style=\"border: 0; padding: 0; width: 100%; background-color: white;\">\r\n" + 
	        				"		<tbody>\r\n" + 
	        				"			<tr>\r\n" + 
	        				"				<td style=\"align-items: center; justify-content: center;\">\r\n" + 
	        				"					<table style=\"border: 0; width: 100%;\">\r\n" + 
	        				"						<tbody>\r\n" + 
	        				"							<tr>\r\n" + 
	        				"								<td style=\"background-color:rgb(245, 245, 245); border-radius: 5px; height: 50px;\">\r\n" + 
	        				"									<!-- this is code website name -->\r\n" + 
	        				"									<h1 style=\"text-align: center; color:black;font-weight:900; font-family: 'Times New Roman', Times, serif; font-weight: bold; font-size: 40px;\"><img src=\"101.png\" alt=\"not\" style=\"width: 50px\"/>DocMeet</h1>\r\n" + 
	        				"								</td>\r\n" + 
	        				"							</tr>\r\n" + 
	        				"						</tbody>\r\n" + 
	        				"					</table>\r\n" + 
	        				"				</td>\r\n" + 
	        				"			</tr>\r\n" + 
	        				"			<tr style=\"display: inline-block;\">\r\n" + 
	        				"				<td style=\"width: 100%; margin-top: 0; border: none; background-color: white;\">\r\n" + 
	        				"					<!-- this is code for user Name -->\r\n" + 
	        				"					<p style=\"color: black; font-size: 25px; text-align: left; align-items: center; margin-top: 0%\">Dear "+signin.getName()+",</p> \r\n" + 
	        				"						<!-- this is code for instruction -->\r\n" + 
	        				"					<p class=\"data\"style=\"text-align: justify-all; align-items: center; font-size: 1.2em; font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif; padding-bottom: 12px; margin: 0.65rem\">Your DocMeet account password is: <span style='font-weight:bold; color:red;'>"+signin.getPassword()+"<span></p> \r\n" +
	        				"					<p class=\"data\"style=\"text-align: justify-all; align-items: center; font-size: 1.2em; font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif; padding-bottom: 12px; margin: 0.65rem\">You can use this password to sign in your account but after successfull login please change your password for security reason.</p> \r\n" +	        				
	        				"				</td>\r\n" + 
	        				"			</tr>\r\n" + 
	        				"			<tr style=\"border: none; background-color: #ffd737; height: 40px; color: white; padding-bottom: 20px; text-align: center;\">\r\n" + 
	        				"				<td>\r\n" + 
	        				"					<p style=\"color: rgb(10, 0, 0); line-height: 1.5em; font-size: 2rem; font-weight: bold\">DocMeet</p> \r\n" + 
	        				"					<a href=\"#\"style=\"border: none; text-decoration: none; padding: 5px;\"> <img src=\"https://icones.pro/wp-content/uploads/2021/02/icone-twitter-violet.png\"alt=\"Image not found\" style=\"width: 30px; height: 30px;\" /></a> \r\n" + 
	        				"					<a href=\"#\"style=\"border: none; text-decoration: none; padding: 5px;\"> <img src=\"https://i.pinimg.com/originals/d2/97/9b/d2979bd98ea37dd3ba4d31c20828ceed.png\"style=\"width: 30px; height: 30px;\" /></a> \r\n" + 
	        				"					<a href=\"#\"style=\"border: none; text-decoration: none; padding: 5px;\"> <img src=\"https://png.pngtree.com/png-clipart/20180626/ourmid/pngtree-instagram-icon-instagram-logo-png-image_3584852.png\"style=\"width: 30px; height: 30px; position: relative; padding-bottom: 0%;\" /></a>\r\n" + 
	        				"				</td>\r\n" + 
	        				"			</tr>\r\n" + 
	        				"			<tr>\r\n" + 
	        				"				<td style=\"text-align: center; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; font-size: 11px; line-height: 18px; color: #393636;\">\r\n" + 
	        				"					<a href=\"#\" target=\"_blank\" style=\"color: #999999; text-decoration: underline;\">PRIVACY STATEMENT</a> | \r\n" + 
	        				"					<a href=\"#\" target=\"_blank\"style=\"color: #999999; text-decoration: underline;\">TERMS OF SERVICE</a> | \r\n" + 
	        				"					<a href=\"#\" target=\"_blank\" style=\"color: #999999; text-decoration: underline;\">RETURNS</a><br>� 2022 DocMeet. All Rights Reserved.<br> If you do not wish to receive any further emails from us, please.\r\n" + 
	        				"					<a href=\"#\"target=\"_blank\" style=\"text-decoration: none; color: #f51919;\">unsubscribe</a>\r\n" + 
	        				"				</td>\r\n" + 
	        				"			</tr>\r\n" + 
	        				"		</tbody>\r\n" + 
	        				"	</table>\r\n" + 
	        				"</body>\r\n" + 
	        				"</html>", "text/html");
	        		Transport.send(msgg);
	        		System.out.println("Send Password email sent...");
	        		break;
			}
		}	
		catch(Exception e)
		{
			System.out.println("Your Register Exception is:- "+e);			
		}
	}
	
	@Transactional
	public String addScheme(Scheme s)
	{
		String msg =(String) this.hibernateTemplate.save(s);		
		return "Sucessfully uploaded scheme with name = "+msg;
	}

	@Transactional
	public Long getCount(String type) 
	{		
		if(type.equals("doc"))
		{
			String s = String.format("select count(*) from DocAdditionalDetails");
			this.session = this.sessionFactory.getCurrentSession();			
			Query query = this.session.createQuery(s);			
			return (Long) query.uniqueResult();
		}
		else 
		{
			String s = String.format("select count(*) from UserDetails");
			this.session = this.sessionFactory.getCurrentSession();			
			Query query = this.session.createQuery(s);
			return (Long) query.uniqueResult();
		}
	}

	@Transactional
	public List<DocAdditionalDetails> getAllDoctor() 
	{		
		return (List<DocAdditionalDetails>) this.hibernateTemplate.loadAll(DocAdditionalDetails.class);
	}
	
	@Transactional
	public List<UserDetails> getAllPatient() 
	{		
		return (List<UserDetails>) this.hibernateTemplate.loadAll(UserDetails.class);
	}

	@Transactional
	public List<Scheme> getAllScheme() 
	{
		List<Scheme> list = this.hibernateTemplate.loadAll(Scheme.class);
		return list;
	}

	@Transactional
	public Long getSchemeCount() 
	{		
		String s = String.format("select count(*) from Scheme");
		this.session = this.sessionFactory.getCurrentSession();
		Query q = this.session.createQuery(s);
		return (Long) q.uniqueResult();
	}

	@Transactional
	public String deleteScheme(String sn) 
	{
		String s= String.format("delete from Scheme where scheme_name='%s'", sn);
		this.session = this.sessionFactory.getCurrentSession();
		Query q = this.session.createQuery(s);
		int i = q.executeUpdate();
		if(i==1)			
			return "Successfully deleted the scheme with name = "+sn;
		else
			return "Error deleting the scheme with name = "+sn;
	}

	@Transactional
	public Scheme printScheme(String sn) 
	{
		this.session = this.sessionFactory.getCurrentSession();
        Criteria c = this.session.createCriteria(Scheme.class);
        c.add(Restrictions.eq("scheme_name", sn));		
		return (Scheme) c.uniqueResult();
	}

	@Transactional
	public String insertFeedback(String name, String email, String feedback) 
	{
		Feedback f = new Feedback(name, email, feedback);
		this.hibernateTemplate.save(f);
		return "Thank you for submitting your valuable feedback!!!";
	}

	@Transactional
	public List<Feedback> getAllFeedbacks() 
	{		
		return this.hibernateTemplate.loadAll(Feedback.class);
	}
	
	@Transactional
	public Long getCountFeedback() 
	{		
		String s = String.format("select count(*) from Feedback");
		this.session = this.sessionFactory.getCurrentSession();
		Query q = this.session.createQuery(s);
		return (Long) q.uniqueResult();
	}
	
}
