package com.das.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tblDiseaseDetails")
public class AddDiseaseDetails 
{
	@Id
	private String diseaseName;
	@Column(name="cause",columnDefinition = "text")
	private String cause; 
	@Column(name="duration")
	private String duration;
	@Column(name="allSymptoms",columnDefinition = "text")
	private String allSymptoms;
	@Column(name="allDrugs",length=10000)
	private String allDrugs;
	@Column(name="allDiagnosis",columnDefinition = "text")
	private String allDiagnosis;	
	private String treatment;
	
	public AddDiseaseDetails() {
		super();
		System.out.println("Inside AddDiseaseDetials class no-arg constructor");
	}

	public AddDiseaseDetails(String diseaseName, String cause, String duration, String allSymptoms, String allDrugs,
			String allDiagnosis, String treatment) {
		super();
		this.diseaseName = diseaseName;
		this.cause = cause;
		this.duration = duration;
		this.allSymptoms = allSymptoms;
		this.allDrugs = allDrugs;
		this.allDiagnosis = allDiagnosis;
		this.treatment = treatment;
	}

	public String getDiseaseName() {
		return diseaseName;
	}

	public void setDiseaseName(String diseaseName) {
		this.diseaseName = diseaseName;
	}

	public String getCause() {
		return cause;
	}

	public void setCause(String cause) {
		this.cause = cause;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public String getAllSymptoms() {
		return allSymptoms;
	}

	public void setAllSymptoms(String allSymptoms) {
		this.allSymptoms = allSymptoms;
	}

	public String getAllDrugs() {
		return allDrugs;
	}

	public void setAllDrugs(String allDrugs) {
		this.allDrugs = allDrugs;
	}

	public String getAllDiagnosis() {
		return allDiagnosis;
	}

	public void setAllDiagnosis(String allDiagnosis) {
		this.allDiagnosis = allDiagnosis;
	}

	public String getTreatment() {
		return treatment;
	}

	public void setTreatment(String treatment) {
		this.treatment = treatment;
	}

	@Override
	public String toString() {
		return "AddDiseaseDetails [diseaseName=" + diseaseName + ", cause=" + cause + ", duration=" + duration
				+ ", allSymptoms=" + allSymptoms + ", allDrugs=" + allDrugs + ", allDiagnosis=" + allDiagnosis
				+ ", treatment=" + treatment + "]";
	}
	
}
