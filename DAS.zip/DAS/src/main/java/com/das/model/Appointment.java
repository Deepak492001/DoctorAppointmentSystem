package com.das.model;

public class Appointment 
{	
	private String doctorEmail;	
	private String patientEmail,patientName,relation,patientGender,appointmentDate,appointmentTime,patientAge,patientMobileNumber;	
	private String bookedDate;
	private String status,mode;
	private String link, prescription;
	private String platformName, meetingLink;
	private String docName, profession;
	
	public Appointment() {
		super();
		System.out.println("Appointment class no-arg class called....");
	}
	
	public Appointment(String doctorEmail, String patientEmail, String patientName, String relation,
			String patientGender, String appointmentDate, String appointmentTime, String patientAge,
			String patientMobileNumber, String bookedDate, String status, String mode, String link, String prescription,
			String platformName, String meetingLink, String docName, String profession) {
		super();
		this.doctorEmail = doctorEmail;
		this.patientEmail = patientEmail;
		this.patientName = patientName;
		this.relation = relation;
		this.patientGender = patientGender;
		this.appointmentDate = appointmentDate;
		this.appointmentTime = appointmentTime;
		this.patientAge = patientAge;
		this.patientMobileNumber = patientMobileNumber;
		this.bookedDate = bookedDate;
		this.status = status;
		this.mode = mode;
		this.link = link;
		this.prescription = prescription;
		this.platformName = platformName;
		this.meetingLink = meetingLink;
		this.docName = docName;
		this.profession = profession;
		
	}
	
	public String getDocName() {
		return docName;
	}

	public void setDocName(String docName) {
		this.docName = docName;
	}

	public String getProfession() {
		return profession;
	}

	public void setProfession(String profession) {
		this.profession = profession;
	}

	public String getDoctorEmail() {
		return doctorEmail;
	}
	public void setDoctorEmail(String doctorEmail) {
		this.doctorEmail = doctorEmail;
	}
	public String getPatientEmail() {
		return patientEmail;
	}
	public void setPatientEmail(String patientEmail) {
		this.patientEmail = patientEmail;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getRelation() {
		return relation;
	}
	public void setRelation(String relation) {
		this.relation = relation;
	}
	public String getPatientGender() {
		return patientGender;
	}
	public void setPatientGender(String patientGender) {
		this.patientGender = patientGender;
	}
	public String getAppointmentDate() {
		return appointmentDate;
	}
	public void setAppointmentDate(String appointmentDate) {
		this.appointmentDate = appointmentDate;
	}
	public String getAppointmentTime() {
		return appointmentTime;
	}
	public void setAppointmentTime(String appointmentTime) {
		this.appointmentTime = appointmentTime;
	}
	public String getPatientAge() {
		return patientAge;
	}
	public void setPatientAge(String patientAge) {
		this.patientAge = patientAge;
	}
	public String getPatientMobileNumber() {
		return patientMobileNumber;
	}
	public void setPatientMobileNumber(String patientMobileNumber) {
		this.patientMobileNumber = patientMobileNumber;
	}
	public String getbookedDate() {
		return bookedDate;
	}
	public void setbookedDate(String bookedDate) {
		this.bookedDate = bookedDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}
	
	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public String getPrescription() {
		return prescription;
	}

	public void setPrescription(String prescription) {
		this.prescription = prescription;
	}
	
	@Override
	public String toString() {
		return "Appointment [ "+" doctorEmail=" + doctorEmail + ", patientEmail=" + patientEmail
				+ ", patientName=" + patientName + ", relation=" + relation + ", patientGender=" + patientGender
				+ ", appointmentDate=" + appointmentDate + ", appointmentTime=" + appointmentTime + ", patientAge="
				+ patientAge + ", patientMobileNumber=" + patientMobileNumber + ", bookedDate=" + bookedDate
				+ ", status=" + status + ", mode=" + mode + ", link=" + link + ", prescription=" + prescription
				+ ", platformName=" + platformName + ", meetingLink=" + meetingLink + ", docName=" + docName
				+ ", profession=" + profession +  "]";
	}

	public String getBookedDate() {
		return bookedDate;
	}

	public void setBookedDate(String bookedDate) {
		this.bookedDate = bookedDate;
	}

	public String getPlatformName() {
		return platformName;
	}

	public void setPlatformName(String platformName) {
		this.platformName = platformName;
	}

	public String getMeetingLink() {
		return meetingLink;
	}

	public void setMeetingLink(String meetingLink) {
		this.meetingLink = meetingLink;
	}

}
