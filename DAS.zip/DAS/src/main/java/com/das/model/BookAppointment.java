package com.das.model;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tblAppointment")
public class BookAppointment 
{	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int sno;
	private String doctorEmail;	
	private String patientEmail,patientName,relation,patientGender,appointmentDate,appointmentTime,patientAge,patientMobileNumber;
	@Column(name="bookedDate")
	private String currentDate;
	private String status,mode;
	private String link, prescription;
	private String platformName, meetingLink;
	
	public BookAppointment() {
		super();
		System.out.println("BookAppointment class no-arg class called....");
	}
	
	public BookAppointment(int sno, String doctorEmail, String patientEmail, String patientName, String relation,
			String patientGender, String appointmentDate, String appointmentTime, String patientAge,
			String patientMobileNumber, String currentDate, String status, String mode, String link,
			String prescription, String platformName, String meetingLink) {
		super();
		this.sno = sno;
		this.doctorEmail = doctorEmail;
		this.patientEmail = patientEmail;
		this.patientName = patientName;
		this.relation = relation;
		this.patientGender = patientGender;
		this.appointmentDate = appointmentDate;
		this.appointmentTime = appointmentTime;
		this.patientAge = patientAge;
		this.patientMobileNumber = patientMobileNumber;
		this.currentDate = currentDate;
		this.status = status;
		this.mode = mode;
		this.link = link;
		this.prescription = prescription;
		this.platformName = platformName;
		this.meetingLink = meetingLink;
	}

	
	public String getDoctorEmail() {
		return doctorEmail;
	}
	public void setDoctorEmail(String doctorEmail) {
		this.doctorEmail = doctorEmail;
	}
	public String getPatientEmail() {
		return patientEmail;
	}
	public void setPatientEmail(String patientEmail) {
		this.patientEmail = patientEmail;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getRelation() {
		return relation;
	}
	public void setRelation(String relation) {
		this.relation = relation;
	}
	public String getPatientGender() {
		return patientGender;
	}
	public void setPatientGender(String patientGender) {
		this.patientGender = patientGender;
	}
	public String getAppointmentDate() {
		return appointmentDate;
	}
	public void setAppointmentDate(String appointmentDate) {
		this.appointmentDate = appointmentDate;
	}
	public String getAppointmentTime() {
		return appointmentTime;
	}
	public void setAppointmentTime(String appointmentTime) {
		this.appointmentTime = appointmentTime;
	}
	public String getPatientAge() {
		return patientAge;
	}
	public void setPatientAge(String patientAge) {
		this.patientAge = patientAge;
	}
	public String getPatientMobileNumber() {
		return patientMobileNumber;
	}
	public void setPatientMobileNumber(String patientMobileNumber) {
		this.patientMobileNumber = patientMobileNumber;
	}
	public String getCurrentDate() {
		return currentDate;
	}
	public void setCurrentDate(String currentDate) {
		this.currentDate = currentDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}
	
	@Override
	public String toString() {
		return "BookAppointment [sno=" + sno + ", doctorEmail=" + doctorEmail + ", patientEmail=" + patientEmail
				+ ", patientName=" + patientName + ", relation=" + relation + ", patientGender=" + patientGender
				+ ", appointmentDate=" + appointmentDate + ", appointmentTime=" + appointmentTime + ", patientAge="
				+ patientAge + ", patientMobileNumber=" + patientMobileNumber + ", currentDate=" + currentDate
				+ ", status=" + status + ", mode=" + mode + ", link=" + link + ", prescription=" + prescription
				+ ", platformName=" + platformName + ", meetingLink=" + meetingLink + "]";
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public String getPrescription() {
		return prescription;
	}

	public void setPrescription(String prescription) {
		this.prescription = prescription;
	}



	
}
