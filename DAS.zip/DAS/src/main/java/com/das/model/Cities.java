package com.das.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tblCity")
public class Cities 
{
	@Id	
	private String city;
	private String state;
	public Cities() {
		super();
		System.out.println("Cities class no-arg constructor called....");
	}
	public Cities(String city, String state) {
		super();
		this.city = city;
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	@Override
	public String toString() {
		return "Cities [city=" + city + ", state=" + state + "]";
	}
}
