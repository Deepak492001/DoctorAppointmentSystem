package com.das.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tblDiseaseName")
public class DiseaseName 
{
	@Id
	private String diseaseName;
	public DiseaseName() {
		super();
		System.out.println("Inside DiseaseName class no-arg constructor...");
	}
	
	public DiseaseName(String diseaseName) {
		super();
		this.diseaseName = diseaseName;
	}
	
	public String getDiseaseName() {
		return diseaseName;
	}

	public void setDiseaseName(String diseaseName) {
		this.diseaseName = diseaseName;
	}

	@Override
	public String toString() {
		return "DiseaseName [diseaseName=" + diseaseName + "]";
	}
}
