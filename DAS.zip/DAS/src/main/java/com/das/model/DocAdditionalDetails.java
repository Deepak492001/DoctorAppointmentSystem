package com.das.model;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tblDocAdditionalDetails")
public class DocAdditionalDetails 
{
	@Id
	private String email;
	private String name,profession;
	private String designation,hospital_name,location,fees,timings;	
	
	public DocAdditionalDetails() 
	{
		System.out.println("DocAdditionalDetails no-arg constructor called...");
	}
	
	public DocAdditionalDetails(String email, String name, String profession, String designation, String hospital_name,
			String location, String fees, String timings) {
		super();
		this.email = email;
		this.name = name;
		this.profession = profession;
		this.designation = designation;
		this.hospital_name = hospital_name;
		this.location = location;
		this.fees = fees;
		this.timings = timings;
	}

	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getHospital_name() {
		return hospital_name;
	}
	public void setHospital_name(String hospital_name) {
		this.hospital_name = hospital_name;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getFees() {
		return fees;
	}
	public void setFees(String fees) {
		this.fees = fees;
	}
	public String getTimings() {
		return timings;
	}
	public void setTimings(String timings) {
		this.timings = timings;
	}

	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getProfession() {
		return profession;
	}


	public void setProfession(String profession) {
		this.profession = profession;
	}


	@Override
	public String toString() {
		return "DocAdditionalDetails [email=" + email + ", name=" + name + ", profession=" + profession
				+ ", designation=" + designation + ", hospital_name=" + hospital_name + ", location=" + location
				+ ", fees=" + fees + ", timings=" + timings + "]";
	}
}
