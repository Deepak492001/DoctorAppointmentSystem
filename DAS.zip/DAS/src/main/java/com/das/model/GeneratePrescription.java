package com.das.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tblPrescription")
public class GeneratePrescription 	
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int pid;
	private String bookedDate, doctorEmail,  medicineDetails, generatedDate;
	
	public GeneratePrescription() {
		super();
		System.out.println("Generate Prescription class no-arg constructor called.....");
	}
	
	public GeneratePrescription(String bookedDate, String doctorEmail, String medicineDetails,
			String generatedDate) {
		super();		
		this.bookedDate = bookedDate;
		this.doctorEmail = doctorEmail;
		this.medicineDetails = medicineDetails;
		this.generatedDate = generatedDate;		
	}
		
	public int getPid() {
		return pid;
	}
	
	public void setPid(int pid) {
		this.pid = pid;
	}
	
	public String getDoctorEmail() {
		return doctorEmail;
	}
	
	public void setDoctorEmail(String doctorEmail) {
		this.doctorEmail = doctorEmail;
	}
	
	public String getMedicineDetails() {
		return medicineDetails;
	}
	
	public void setMedicineDetails(String medicineDetails) {
		this.medicineDetails = medicineDetails;
	}
	
	public String getGeneratedDate() {
		return generatedDate;
	}
	
	public void setGeneratedDate(String generatedDate) {
		this.generatedDate = generatedDate;
	}
	
	public String getBookedDate() {
		return bookedDate;
	}

	public void setBookedDate(String bookedDate) {
		this.bookedDate = bookedDate;
	}

	@Override
	public String toString() {
		return "GeneratePrescription [pid=" + pid + ", bookedDate=" + bookedDate + ", doctorEmail=" + doctorEmail
				+ ", medicineDetails=" + medicineDetails + ", generatedDate=" + generatedDate + "]";
	}

}
