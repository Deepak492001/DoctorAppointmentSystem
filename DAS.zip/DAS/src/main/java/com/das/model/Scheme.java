package com.das.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tblScheme")
public class Scheme 
{
	@Id
	private String scheme_name;
	private String announced_by, description, benefits, targeted_people, where_to_avail, documents, link, uploaded_date;

	public Scheme() {
		super();
		System.out.println("Scheme class no-arg constructor called..");
	}

	public Scheme(String scheme_name, String announced_by, String description, String benefits, String targeted_people,
			String where_to_avail, String documents, String link, String uploaded_date) {
		super();
		this.scheme_name = scheme_name;
		this.announced_by = announced_by;
		this.description = description;
		this.benefits = benefits;
		this.targeted_people = targeted_people;
		this.where_to_avail = where_to_avail;
		this.documents = documents;
		this.link = link;
		this.uploaded_date = uploaded_date;
	}


	public String getScheme_name() {
		return scheme_name;
	}

	public void setScheme_name(String scheme_name) {
		this.scheme_name = scheme_name;
	}

	public String getAnnounced_by() {
		return announced_by;
	}

	public void setAnnounced_by(String announced_by) {
		this.announced_by = announced_by;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getBenefits() {
		return benefits;
	}

	public void setBenefits(String benefits) {
		this.benefits = benefits;
	}

	public String getTargeted_people() {
		return targeted_people;
	}

	public void setTargeted_people(String targeted_people) {
		this.targeted_people = targeted_people;
	}

	public String getWhere_to_avail() {
		return where_to_avail;
	}

	public void setWhere_to_avail(String where_to_avail) {
		this.where_to_avail = where_to_avail;
	}

	public String getDocuments() {
		return documents;
	}

	public void setDocuments(String documents) {
		this.documents = documents;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public String getUploaded_date() {
		return uploaded_date;
	}

	public void setUploaded_date(String uploaded_date) {
		this.uploaded_date = uploaded_date;
	}

	@Override
	public String toString() {
		return "Scheme [scheme_name=" + scheme_name + ", announced_by=" + announced_by + ", description=" + description
				+ ", benefits=" + benefits + ", targeted_people=" + targeted_people + ", where_to_avail="
				+ where_to_avail + ", documents=" + documents + ", link=" + link + ", uploaded_date=" + uploaded_date
				+ "]";
	}
	
}
