package com.das.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tblsignin")
public class SignIn 
{
	@Id
	private String email;
	private String password,name,type,status;
	
	public SignIn() 
	{
		System.out.println("SignIn class no-arg constructor called...");
	}

	public SignIn(String email, String password, String name, String type, String status) {
		super();
		this.email = email;
		this.password = password;
		this.name = name;
		this.type = type;
		this.status = status;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "SignIn [email=" + email + ", password=" + password + ", name=" + name + ", type=" + type + ", status="
				+ status + "]";
	}
	
}
