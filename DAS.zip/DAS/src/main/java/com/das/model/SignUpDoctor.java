package com.das.model;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name= "tblDoctorDetails")
public class SignUpDoctor 
{
	@Id
	private String email;
	private String name,dob,mobile,emerMobile,address,work_hidden,edu_hidden,si_hidden,password;
	public SignUpDoctor() 
	{
		System.out.println("Doctor class no-arg constructor called...");
	}
	public SignUpDoctor(String email, String name, String dob, String mobile, String emerMobile, String address,
			String work_hidden, String edu_hidden, String si_hidden, String password) {
		super();
		this.email = email;
		this.name = name;
		this.dob = dob;
		this.mobile = mobile;
		this.emerMobile = emerMobile;
		this.address = address;
		this.work_hidden = work_hidden;
		this.edu_hidden = edu_hidden;
		this.si_hidden = si_hidden;
		this.password = password;
	}
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getEmerMobile() {
		return emerMobile;
	}
	public void setEmerMobile(String emerMobile) {
		this.emerMobile = emerMobile;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getWork_hidden() {
		return work_hidden;
	}
	public void setWork_hidden(String work_hidden) {
		this.work_hidden = work_hidden;
	}
	public String getEdu_hidden() {
		return edu_hidden;
	}
	public void setEdu_hidden(String edu_hidden) {
		this.edu_hidden = edu_hidden;
	}
	public String getSi_hidden() {
		return si_hidden;
	}
	public void setSi_hidden(String si_hidden) {
		this.si_hidden = si_hidden;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "SignUpDoctor [email=" + email + ", name=" + name + ", dob=" + dob + ", mobile=" + mobile
				+ ", emerMobile=" + emerMobile + ", address=" + address + ", work_hidden=" + work_hidden
				+ ", edu_hidden=" + edu_hidden + ", si_hidden=" + si_hidden + ", password=" + password + "]";
	}
}
