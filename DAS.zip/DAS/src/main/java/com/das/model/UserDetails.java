package com.das.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tblUser")
public class UserDetails 
{
	@Id
	private String email;
	private String name, dob, mobile, stateAndCity, address, gender, password;  
	public UserDetails() {
		super();
		System.out.println("Inside UserDetails class no-arg constructor...");
	}
	public UserDetails(String email, String name, String dob, String mobile, String stateAndCity,
			String address, String gender, String password) {
		super();
		this.email = email;
		this.name = name;
		this.dob = dob;
		this.mobile = mobile;
		this.stateAndCity = stateAndCity;
		this.address = address;
		this.gender = gender;
		this.password = password;
	}
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getStateAndCity() {
		return stateAndCity;
	}
	public void setState(String stateAndCity) {
		this.stateAndCity = stateAndCity;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "UserDetails [email=" + email + ", name=" + name + ", dob=" + dob + ", mobile=" + mobile + ", stateAndCity="
				+ stateAndCity +  ", address=" + address + ", gender=" + gender
				+ ", password=" + password + "]";
	}
}
