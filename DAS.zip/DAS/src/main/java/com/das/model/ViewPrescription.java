package com.das.model;

public class ViewPrescription 
{
	private int pid;
	private String bookedDate, generatedDate, location;
	private String hospitalName, timings;
	private String patientName, appointmentDate, patientMobileNumber, patientGender, patientAge, patientEmail;
	private String name, email,  medicineDetails, profession;
	
	public ViewPrescription() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ViewPrescription(int pid, String bookedDate, String generatedDate, String location, String hospitalName,
			String timings, String patientName, String appointmentDate, String patientMobileNumber,
			String patientGender, String patientAge, String patientEmail, String name, String email,
			String medicineDetails, String profession) {
		super();
		this.pid = pid;
		this.bookedDate = bookedDate;
		this.generatedDate = generatedDate;
		this.location = location;
		this.hospitalName = hospitalName;
		this.timings = timings;
		this.patientName = patientName;
		this.appointmentDate = appointmentDate;
		this.patientMobileNumber = patientMobileNumber;
		this.patientGender = patientGender;
		this.patientAge = patientAge;
		this.patientEmail = patientEmail;
		this.name = name;
		this.email = email;		
		this.medicineDetails = medicineDetails;
		this.profession = profession;
	}

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public String getBookedDate() {
		return bookedDate;
	}

	public void setBookedDate(String bookedDate) {
		this.bookedDate = bookedDate;
	}

	public String getGeneratedDate() {
		return generatedDate;
	}

	public void setGeneratedDate(String generatedDate) {
		this.generatedDate = generatedDate;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getHospitalName() {
		return hospitalName;
	}

	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}

	public String getTimings() {
		return timings;
	}

	public void setTimings(String timings) {
		this.timings = timings;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getAppointmentDate() {
		return appointmentDate;
	}

	public void setAppointmentDate(String appointmentDate) {
		this.appointmentDate = appointmentDate;
	}

	public String getPatientMobileNumber() {
		return patientMobileNumber;
	}

	public void setPatientMobileNumber(String patientMobileNumber) {
		this.patientMobileNumber = patientMobileNumber;
	}

	public String getPatientGender() {
		return patientGender;
	}

	public void setPatientGender(String patientGender) {
		this.patientGender = patientGender;
	}

	public String getPatientAge() {
		return patientAge;
	}

	public void setPatientAge(String patientAge) {
		this.patientAge = patientAge;
	}

	public String getPatientEmail() {
		return patientEmail;
	}

	public void setPatientEmail(String patientEmail) {
		this.patientEmail = patientEmail;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMedicineDetails() {
		return medicineDetails;
	}

	public void setMedicineDetails(String medicineDetails) {
		this.medicineDetails = medicineDetails;
	}

	public String getProfession() {
		return profession;
	}

	public void setProfession(String profession) {
		this.profession = profession;
	}

	@Override
	public String toString() {
		return "ViewPrescription [pid=" + pid + ", bookedDate=" + bookedDate + ", generatedDate=" + generatedDate
				+ ", location=" + location + ", hospitalName=" + hospitalName + ", timings=" + timings
				+ ", patientName=" + patientName + ", appointmentDate=" + appointmentDate + ", patientMobileNumber="
				+ patientMobileNumber + ", patientGender=" + patientGender + ", patientAge=" + patientAge
				+ ", patientEmail=" + patientEmail + ", name=" + name + ", email=" + email  
				+ ", medicineDetails=" + medicineDetails + ", profession=" + profession + "]";
	}

}
