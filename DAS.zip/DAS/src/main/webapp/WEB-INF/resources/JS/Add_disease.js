
let addSymp = document.getElementById("addSymp"); // add button
let addMoreSymp = document.getElementById("addMoreSymp"); //add more button
let symptoms = document.getElementById("Symptoms"); //div
let symptom = document.getElementById("symptom"); // symptom input
let allSymptoms = document.getElementById("allSymptoms"); // hidden input

addSymp.addEventListener('click',function()
{       
    allSymptoms.value += ">	"+symptom.value+"	|	";
    let u = document.createElement('ul');    
    let l = document.createElement('li');    
    l.innerHTML += symptom.value+"\n";
    u.appendChild(l);    
    symptoms.appendChild(u);
});

addMoreSymp.addEventListener('click',function()
{
    symptom.value="";
});


let addDrugs = document.getElementById("addDrugs"); // add button
let addMoreDrugs = document.getElementById("addMoreDrugs"); //add more button
let drugs = document.getElementById("drugs"); //div
let drug = document.getElementById("drug"); // drug input
let allDrugs = document.getElementById("allDrugs"); // hidden input

addDrugs.addEventListener('click',function()
{       
    allDrugs.value += "> "+drug.value+"	|	";
    let u = document.createElement('ul');    
    let l = document.createElement('li');    
    l.innerHTML += drug.value+"\n";
    u.appendChild(l);    
    drugs.appendChild(u);
});

addMoreDrugs.addEventListener('click',function()
{
    drug.value="";
});

let addDiagnosis = document.getElementById("addDiagnosis"); // add button
let addMoreDiagnosis = document.getElementById("addMoreDiagnosis"); //add more button
let diag = document.getElementById("diag"); //div
let diagnosis = document.getElementById("diagnosis"); // drug input
let allDiagnosis = document.getElementById("allDiagnosis"); // hidden input

addDiagnosis.addEventListener('click',function()
{       
    allDiagnosis.value += "> "+diagnosis.value+"	|	";
    let u = document.createElement('ul');    
    let l = document.createElement('li');    
    l.innerHTML += diagnosis.value+"\n";
    u.appendChild(l);    
    diag.appendChild(u);
});

addMoreDiagnosis.addEventListener('click',function()
{
    diagnosis.value="";
});



