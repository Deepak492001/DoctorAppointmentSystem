
// targeted input
let benefit_input = document.getElementById("benefit_input");
let target_input = document.getElementById("target_input");
let document_input = document.getElementById("document_input");

// hidden inputs
let benefits = document.getElementById("benefits");
let targeted_people = document.getElementById("targeted_people");
let documents = document.getElementById("documents");

// info divs
let benefit_info = document.getElementById("benefit_info");
let target_info = document.getElementById("target_info");
let document_info = document.getElementById("document_info");


// add buttons
let benefit_add = document.getElementById("benefit_add");
let target_add = document.getElementById("target_add");
let document_add = document.getElementById("document_add");

// add more buttons
let benefit_add_more = document.getElementById("benefit_add_more");
let target_add_more = document.getElementById("target_add_more");
let document_add_more = document.getElementById("document_add_more");


//for benefits add button
let b = 1;
benefit_add.addEventListener('click',function()
{
    benefits.value+= benefit_input.value + "|";    
    benefit_info.innerHTML = "Benefits added :- "+(b++);
});

// for benefits add_more button
benefit_add_more.addEventListener('click', function()
{
    benefit_input.value=" ";
});

// for targeted_people add button
let t = 1;
target_add.addEventListener('click',function()
{
    targeted_people.value += target_input.value + "|";    
    target_info.innerHTML = "Potential targeted people :- "+(t++);
});

// for targeted_pople add_more button
target_add_more.addEventListener('click', function()
{
    target_input.value=" ";
});


// for documents add button
let c = 1;
document_add.addEventListener('click',function()
{
    documents.value += document_input.value + "|";    
    doc_info.innerHTML = "Documents added :- "+(c++);
});

// for documents add_more button
document_add_more.addEventListener('click', function()
{
    document_input.value=" ";
});
