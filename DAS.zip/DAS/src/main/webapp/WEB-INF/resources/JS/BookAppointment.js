
let time = ['8:45 AM - 9:15 AM','9:30 AM - 10:00 AM','10:15 AM - 10:45 AM','11:00 AM - 11:30 AM','11:45 AM - 12:15 PM','12:30 PM - 01:00 PM','02:00 PM - 02:30 PM'];


let btn1 = document.getElementsByClassName("timeSlot0");
console.log(btn1[0]);

let hideTime = document.getElementsByClassName("hiddenTime");
console.log(hideTime[0]);

let d= document.getElementsByClassName("timeSlots");
console.log(d);

for(i=0;i<time.length;i++)
{
    console.log("hello");
    let newBtn = btn1[0].cloneNode(true);
    d[0].appendChild(newBtn);    
    newBtn.innerHTML=time[i];    
    newBtn.className="btn btn-info shadow mx-2 timeSlot0";
}


btn1[0].addEventListener('click',function()
{
    let text = btn1[0].innerHTML;
    hideTime[0].value=text;
});

btn1[1].addEventListener('click',function()
{
    let text = btn1[1].innerHTML;
    hideTime[0].value=text;
});

btn1[2].addEventListener('click',function()
{
    let text = btn1[2].innerHTML;
    hideTime[0].value=text;
});

btn1[3].addEventListener('click',function()
{
    let text = btn1[3].innerHTML;
    hideTime[0].value=text;
});

btn1[4].addEventListener('click',function()
{
    let text = btn1[4].innerHTML;
    hideTime[0].value=text;
});

btn1[5].addEventListener('click',function()
{
    let text = btn1[5].innerHTML;
    hideTime[0].value=text;
});

btn1[6].addEventListener('click',function()
{
    let text = btn1[6].innerHTML;
    hideTime[0].value=text;
});

btn1[7].addEventListener('click',function()
{
    let text = btn1[7].innerHTML;
    hideTime[0].value=text;
});

