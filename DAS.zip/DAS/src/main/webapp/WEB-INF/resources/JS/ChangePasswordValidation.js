
let curr = document.getElementById("curr");

let new_ = document.getElementById("new") ;

let validation1 = document.getElementById("validation1") ;

let re = document.getElementById("re");

let validation2 = document.getElementById("validation2") ;

new_.addEventListener('keyup',function()
{   

    if(new_.value.length == 0)
    {
        validation1.firstElementChild.innerHTML = "Password field cann't be empty.";    
        validation1.firstElementChild.style.cssText = "color:red"
    }

    if((new_.value.length) > 0 && (new_.value.length) < 8)
    {
        validation1.firstElementChild.innerHTML = "Password length should be 8 character long.";
        validation1.firstElementChild.style.cssText = "color:red"
    }
    if((new_.value) === (curr.value))
    {        
        validation1.firstElementChild.innerHTML = "New password should not be same as previous password.";
        validation1.firstElementChild.style.cssText = "color:red"
    }
    if(((new_.value.length) >= 8) && !((new_.value) === (curr.value)))
        validation1.firstElementChild.innerHTML = " ";
    

    
});

re.addEventListener('keyup',function()
{   

    if(!(re.value === new_.value))
    {        
        validation2.firstElementChild.innerHTML = "Password doesn't matched.";
        validation2.firstElementChild.style.cssText = "color:red"
    }
    if( re.value === new_.value)   
        validation2.firstElementChild.innerHTML = " ";

    
});



