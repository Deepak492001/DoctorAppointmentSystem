let clip = document.getElementById("clip");
let link = document.getElementById("link").innerHTML;
let msg = document.getElementById("msg");

clip.addEventListener('click', function()
{    
    try {
        navigator.clipboard.writeText(link);
        msg.innerHTML = "Link copied to clipboard successfully!!!";
        msg.style="color:green;font-family:serif";        
        console.log('Content copied to clipboard');
    } catch (err) {
        console.error('Failed to copy: ', err);
        msg.innerHTML = "Error in copying link to clipboard!!!";
        msg.style="color:red;font-family:serif";
    }
})


