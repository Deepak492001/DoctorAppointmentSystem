
let from_time = document.getElementsByClassName("from_time");
let to_time = document.getElementsByClassName("to_time");
let submit_button = document.getElementsByClassName("submit_button");
let timings = document.getElementsByClassName("timings");
let days = document.getElementsByClassName("days");


submit_button[0].addEventListener("click",function()
{
    for (var day of days)
    {
        if (day.checked) 
        {
            timings[0].value = day.value +"  "+ from_time[0].value +" - "+ to_time[0].value;        
        }
    }
    
    
});

