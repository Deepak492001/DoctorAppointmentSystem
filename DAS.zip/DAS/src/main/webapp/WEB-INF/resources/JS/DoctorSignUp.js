
let work_add = document.getElementsByClassName("work_add");
let work_title = document.getElementsByClassName("work_title");
let work_location = document.getElementsByClassName("work_location");
let div = document.getElementsByClassName("hidden");

work_add[0].addEventListener("click",function()
{	
	console.log("Hello "+work_title[0].innerHTML +"  "+work_location[0].innerHTML);
});

