
let pop = document.getElementsByClassName("popup");

let main_div = document.getElementsByClassName("main_div");

pop[0].setAttribute("style","display:none;");

let signup_link = document.getElementsByClassName("signup_link");
console.log(signup_link[0]);

signup_link[0].addEventListener("click",function()
{
	//main_div[0].setAttribute("style","opacity:0.4;");		
	pop[0].setAttribute("style","display:inline-block;");

});

let cancel = document.getElementsByClassName("cancel");
cancel[0].addEventListener("click",function()
{
	pop[0].setAttribute("style","display:none;");
});






