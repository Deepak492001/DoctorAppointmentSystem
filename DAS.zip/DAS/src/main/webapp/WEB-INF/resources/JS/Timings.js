
let timings = document.getElementsByClassName("timings");
console.log(timings);

let from = document.getElementsByClassName("from");
console.log(from);

let to = document.getElementsByClassName("to");
console.log(to);

let submit = document.getElementsByClassName("submit");
console.log(submit);

let weekDays = document.getElementsByClassName("weekDays");
console.log(weekDays);

let ques = document.getElementsByClassName("ques");
console.log(ques);

for(let i=0;i<weekDays.length; i++)
    weekDays[i].disabled = true;
    
from[0].disabled = true;
to[0].disabled = true;
submit[0].disabled = true;

ques[0].addEventListener( "click", () => {
    if ( ques[0].checked ) 
    {
        console.log("hello checked");
        for(let i=0;i<weekDays.length; i++)
            weekDays[i].disabled = false;

        from[0].disabled = false;
        to[0].disabled = false;
        submit[0].disabled = false;
                
    } 
    else
    {        
        for(let i=0;i<weekDays.length; i++)
            weekDays[i].disabled = true;
    
        from[0].disabled = true;
        to[0].disabled = true;
        submit[0].disabled = true;

    }
});


for(let i=0;i<weekDays.length;i++)
{
    weekDays[i].addEventListener( "change", () => {
        if ( weekDays[i].checked ) {
            timings[0].value += weekDays[i].value+" - ";
        } 
    });
}    

submit[0].addEventListener('click', function()
{
    timings[0].value += from[0].value+" - "+to[0].value;
    console.log(timings[0].value);
});



