

let table = document.getElementById("approvedTable");
let tableRowCount =  table.childElementCount;

let medsName = document.getElementsByClassName("medsName");

let note = document.getElementsByClassName("note");

let dosageTime = document.getElementsByName("dosageTime");

let meal = document.getElementsByName("meal");

let add = document.getElementsByClassName("add");

let addMore = document.getElementsByClassName("addMore");

let medicineDetails = document.getElementsByClassName("medicineDetails");

let count = document.getElementsByClassName("count");


function getDosageTime()
{
    for(i = 0; i < dosageTime.length; i++) 
    {
        if(dosageTime[i].checked)
            return dosageTime[i].value;
    }    
}

function getMeal()
{
    for(i = 0; i < meal.length; i++) 
    {
        if(meal[i].checked)
            return meal[i].value;
    }    
}

for(let i=0; i<tableRowCount; i++)
{
	let countMedicine =0;
	add[i].addEventListener('click',function()
	{		
		medicineDetails[i].value += medsName[i].value +" - ( "+note[i].value +" ) - "+getDosageTime()+" - "+getMeal()+" | \n";  
	    countMedicine++;
	    count[i].innerHTML = countMedicine+" Medicines Added..."
	});
}

for(let i=0; i<tableRowCount; i++)
{

	addMore[i].addEventListener('click',function()
	{
	    medsName[i].value="";
	    note[i].value="";
	    for(i = 0; i < dosageTime.length; i++) 
	    {
	        dosageTime[i].checked = false;            
	    }        
	    for(i = 0; i < meal.length; i++) 
	    {
	        meal[i].checked = false;            
	    }
	});
	
}


