
// Some global variables
let work_angle_down_button_clicked = true;
let education_angle_down_button_clicked = true;
let si_angle_down_button_clicked = true;


// Work Experience
let work_angle_down = document.getElementsByClassName("work_angle_down");
let work_content = document.getElementsByClassName("work_content");
work_content[0].setAttribute("style","display:none;");

work_angle_down[0].addEventListener("click",function()
{
    
    if(work_angle_down_button_clicked)
    {
        work_angle_down[0].innerHTML = `<i class="fa-solid fa-angle-up fa-1x " style="text-align:right"></i>`;
        work_content[0].setAttribute("style","display:block;");        
        work_angle_down_button_clicked = false;    
    }
    else
    {
        work_angle_down[0].innerHTML = `<i class="fa-solid fa-angle-down fa-1x " style="text-align:right"></i>`;
        work_content[0].setAttribute("style","display:none;");
        work_angle_down_button_clicked = true;        
    }
});


// Education and Training
let education_angle_down = document.getElementsByClassName("education_angle_down");
let education_content = document.getElementsByClassName("education_content");
education_content[0].setAttribute("style","display:none;");

education_angle_down[0].addEventListener("click",function()
{
    
    if(education_angle_down_button_clicked)
    {
        education_angle_down[0].innerHTML = `<i class="fa-solid fa-angle-up fa-1x " style="text-align:right"></i>`;
        education_content[0].setAttribute("style","display:block;");        
        education_angle_down_button_clicked = false;    
    }
    else
    {
        education_angle_down[0].innerHTML = `<i class="fa-solid fa-angle-down fa-1x " style="text-align:right"></i>`;
        education_content[0].setAttribute("style","display:none;");
        education_angle_down_button_clicked = true;        
    }
});


// Special Interest
let si_angle_down = document.getElementsByClassName("si_angle_down");
let si_content = document.getElementsByClassName("si_content");
si_content[0].setAttribute("style","display:none;");

si_angle_down[0].addEventListener("click",function()
{
    
    if(si_angle_down_button_clicked)
    {
        si_angle_down_button_clicked = false;    
        si_content[0].setAttribute("style","display:block;");        
        si_angle_down[0].innerHTML = `<i class="fa-solid fa-angle-up fa-1x " style="text-align:right"></i>`;
    }
    else
    {
        si_angle_down[0].innerHTML = `<i class="fa-solid fa-angle-down fa-1x " style="text-align:right"></i>`;
        si_content[0].setAttribute("style","display:none;");
        si_angle_down_button_clicked = true;        
    }
});
