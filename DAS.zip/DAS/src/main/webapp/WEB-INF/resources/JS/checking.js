

let ele=document.getElementsByClassName("main_div");
console.log(ele);
console.log("Length = "+ele.length);


let clone=ele[0].cloneNode(true);
console.log(clone);
clone.className +=" main_div2";


document.body.appendChild(clone);
document.body.appendChild(clone);

let css=getComputedStyle(ele[0]);
console.log(css);
console.log(css.backgroundColor);

let first_child=ele[0].firstElementChild;
console.log(first_child);

let ele2=document.getElementsByClassName("main_div2");
console.log(ele2);

let ele2_first_child=ele2[0].firstElementChild.firstElementChild;
console.log(ele2_first_child);

ele2_first_child.setAttribute("style",`	content: url("pic2.png");`);








