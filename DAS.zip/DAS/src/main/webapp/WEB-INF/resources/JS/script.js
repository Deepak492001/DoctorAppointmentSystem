

let cards_container=document.getElementsByClassName("cards_container");
console.log(cards_container);

let doc_card=document.getElementsByClassName("cards");


function cloning( no_of_times )
{
	for(let i=0; i<no_of_times; i++)
	{
		let clone_doc_card=doc_card[0].cloneNode(true);
		clone_doc_card.className += " cards"+(i+1);
		cards_container[0].appendChild(clone_doc_card);
		
		
	}
} 	
cloning(2);

function changingElementContentOfCloneCards(ClassName,url,DocName,desc)
{
	let cards = document.getElementsByClassName(ClassName);
	let cards_first_child = cards[0].firstElementChild.firstElementChild;
	cards_first_child.setAttribute("style","content:url('"+`${url}`+"')");	
	let cards_second_child = cards[0].firstElementChild.nextElementSibling.firstElementChild;
	cards_second_child.innerHTML=DocName;
	let cards_third_child = cards[0].firstElementChild.nextElementSibling.nextElementSibling.firstElementChild;
	cards_third_child.innerHTML=desc;
}

changingElementContentOfCloneCards("cards1","https://img.freepik.com/free-vector/doctor-character-background_1270-84.jpg?w=2000","Aman Juyal","Hello everyone!!! I am Aman Juyal Web Developer having 2 yrs experience...");
changingElementContentOfCloneCards("cards2","https://static.vecteezy.com/system/resources/previews/007/933/971/original/professional-doctors-and-nurses-in-masks-illustration-in-flat-style-vector.jpg","Ankit Joshi","Hello everyone!!! I am Ankit Joshi Web Developer having 1 yrs experience...");








